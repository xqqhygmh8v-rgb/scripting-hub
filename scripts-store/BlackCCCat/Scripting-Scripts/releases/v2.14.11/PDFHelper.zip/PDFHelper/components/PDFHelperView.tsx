import {
  Button,
  EmptyView,
  Group,
  HStack,
  Image,
  List,
  Menu,
  NavigationStack,
  Path,
  ProgressView,
  Spacer,
  Text,
  VStack,
  ZStack,
  useCallback,
  useMemo,
  useState,
} from "scripting"
import type { SourceItem } from "../types"
import { useMarkdownReleaseNotesSheet } from "./ReleaseNotesSheet"
import { SourceBlockView } from "./SourceBlockView"
import { chooseImportInitialDirectory, pickSourcesFromFiles, pickSourcesFromPhotos } from "../utils/importer"
import { buildOutputFileName } from "../utils/id"
import { convertSelectedImagesToPdf, getSelectedPages, mergeSelectedPagesToPdf } from "../utils/pdf_ops"

function isUserCancelled(error: any): boolean {
  const message = String(error?.message ?? error ?? "").toLowerCase()
  return message.includes("cancel")
}

async function saveExportedPdf(data: Data, fileName: string) {
  const result = await DocumentPicker.exportFiles({
    files: [{ data, name: fileName }],
  })

  if (result.length > 0) {
    await Dialog.alert({
      title: "保存成功",
      message: `已保存：${result[0]}`,
    })
  }
}

async function buildPreviewFilePath(data: Data, fileName: string): Promise<string> {
  const previewPath = Path.join(FileManager.temporaryDirectory, fileName)
  await FileManager.writeAsData(previewPath, data)
  return previewPath
}

async function previewExportedPdf(data: Data, fileName: string) {
  const previewPath = await buildPreviewFilePath(data, fileName)
  try {
    await QuickLook.previewURLs([previewPath], true)
  } finally {
    try {
      await FileManager.remove(previewPath)
    } catch {
    }
  }
}

async function presentExportActionSheet(data: Data, fileName: string, summary: string) {
  const action = await Dialog.actionSheet({
    title: summary,
    message: "请选择后续操作",
    cancelButton: false,
    actions: [
      { label: "保存" },
      { label: "预览" },
      { label: "取消", destructive: true },
    ],
  })

  if (action === 0) {
    await saveExportedPdf(data, fileName)
    return
  }

  if (action === 1) {
    await previewExportedPdf(data, fileName)
  }
}

function getMaxSelectedOrder(sources: SourceItem[]): number {
  let max = 0
  for (const source of sources) {
    for (const page of source.pages) {
      if (page.selected && typeof page.selectedOrder === "number" && page.selectedOrder > max) {
        max = page.selectedOrder
      }
    }
  }
  return max
}

function assignSelectionOrderForImported(
  sources: SourceItem[],
  startOrder: number
): SourceItem[] {
  let order = startOrder
  return sources.map((source) => ({
    ...source,
    pages: source.pages.map((page) => {
      if (!page.selected) return { ...page, selectedOrder: undefined }
      const nextPage = { ...page, selectedOrder: order }
      order += 1
      return nextPage
    }),
  }))
}

function compactSelectionOrders(sources: SourceItem[]): SourceItem[] {
  const selectedRows: Array<{ sourceId: string; pageId: string; order: number }> = []

  for (const source of sources) {
    for (const page of source.pages) {
      if (!page.selected) continue
      selectedRows.push({
        sourceId: source.id,
        pageId: page.id,
        order: typeof page.selectedOrder === "number" ? page.selectedOrder : Number.MAX_SAFE_INTEGER,
      })
    }
  }

  selectedRows.sort((a, b) => a.order - b.order)
  const orderMap = new Map<string, number>()
  selectedRows.forEach((row, index) => {
    orderMap.set(`${row.sourceId}::${row.pageId}`, index + 1)
  })

  return sources.map((source) => ({
    ...source,
    pages: source.pages.map((page) =>
      page.selected
        ? { ...page, selectedOrder: orderMap.get(`${source.id}::${page.id}`) }
        : { ...page, selectedOrder: undefined }
    ),
  }))
}

function getImportedPdfSources(sources: SourceItem[]): SourceItem[] {
  return sources.filter((source) => source.kind === "pdf")
}

function getImportedPdfFilePaths(sources: SourceItem[]): string[] {
  const paths = new Set<string>()
  for (const source of sources) {
    if (source.kind !== "pdf") continue
    if (source.originalPath) {
      paths.add(source.originalPath)
      continue
    }
    for (const page of source.pages) {
      if (page.kind === "pdf" || page.kind === "pdf-whole") {
        paths.add(page.pdfPath)
      }
    }
  }
  return [...paths]
}

function removeSourcesByPdfPaths(sources: SourceItem[], pdfPaths: Set<string>): SourceItem[] {
  return compactSelectionOrders(
    sources.filter((source) => {
      if (source.kind !== "pdf") return true
      if (source.originalPath && pdfPaths.has(source.originalPath)) return false
      return !source.pages.some((page) =>
        (page.kind === "pdf" || page.kind === "pdf-whole") && pdfPaths.has(page.pdfPath)
      )
    })
  )
}

function BottomActionButton(props: {
  title: string
  systemImage: string
  disabled: boolean
  action: () => void
}) {
  const background = props.disabled ? "#5B6472" : "#0A66D8"

  return (
    <Button
      buttonStyle="plain"
      disabled={props.disabled}
      action={props.action}
      frame={{ maxWidth: "infinity", minHeight: 46 }}
    >
      <HStack
        spacing={7}
        frame={{ maxWidth: "infinity", minHeight: 46, alignment: "center" as any }}
        background={background}
        clipShape={{ type: "rect", cornerRadius: 12, style: "continuous" } as any}
        contentShape="rect"
      >
        <Image systemName={props.systemImage} foregroundStyle="white" imageScale="medium" />
        <Text font="headline" fontWeight="semibold" foregroundStyle="white">
          {props.title}
        </Text>
      </HStack>
    </Button>
  )
}

export function PDFHelperView() {
  const releaseNotesSheet = useMarkdownReleaseNotesSheet({
    markdownFile: "changelog.md",
    storageKey: "pdfhelper:release-notes:last-seen-hash",
    title: "更新说明",
  })
  const [sources, setSources] = useState<SourceItem[]>([])
  const [loadingMessage, setLoadingMessage] = useState<string | null>(null)
  const [processing, setProcessing] = useState<boolean>(false)

  const selectedPages = useMemo(() => getSelectedPages(sources), [sources])
  const importedPdfSources = useMemo(() => getImportedPdfSources(sources), [sources])
  const importedPdfFilePaths = useMemo(() => getImportedPdfFilePaths(sources), [sources])
  const selectedImageCount = useMemo(
    () => selectedPages.filter((page) => page.kind === "image").length,
    [selectedPages]
  )
  const selectedTotalPageCount = useMemo(() => {
    let count = 0
    for (const page of selectedPages) {
      if (page.kind === "pdf-whole") count += page.pageCount
      else count += 1
    }
    return count
  }, [selectedPages])

  const isBusy = processing || loadingMessage !== null
  const canConvert = selectedImageCount > 0 && !isBusy
  const canMerge = selectedPages.length > 0 && !isBusy
  const canDeleteSelected = selectedPages.length > 0 && !isBusy
  const hasAnyItems = sources.length > 0
  const deleteButtonDisabled = isBusy || !hasAnyItems

  const togglePage = useCallback((sourceId: string, pageId: string) => {
    setSources((prev) => {
      const currentMax = getMaxSelectedOrder(prev)
      const next = prev.map((source) =>
        source.id !== sourceId
          ? source
          : {
            ...source,
            pages: source.pages.map((page) =>
              page.id === pageId
                ? page.selected
                  ? { ...page, selected: false, selectedOrder: undefined }
                  : { ...page, selected: true, selectedOrder: currentMax + 1 }
                : page
            ),
          }
      )
      return compactSelectionOrders(next)
    })
  }, [])

  const deletePage = useCallback((sourceId: string, pageId: string) => {
    setSources((prev) =>
      compactSelectionOrders(
        prev
          .map((source) =>
            source.id !== sourceId
              ? source
              : { ...source, pages: source.pages.filter((page) => page.id !== pageId) }
          )
          .filter((source) => source.pages.length > 0)
      )
    )
  }, [])

  const addFromFiles = useCallback(async () => {
    if (isBusy) return
    setLoadingMessage("正在导入文件...")
    try {
      const imported = await pickSourcesFromFiles()
      if (imported.sources.length > 0) {
        setSources((prev) => {
          const start = getMaxSelectedOrder(prev) + 1
          return [...prev, ...assignSelectionOrderForImported(imported.sources, start)]
        })
      }
      if (imported.notices.length > 0) {
        await Dialog.alert({
          title: "导入提示",
          message: imported.notices.join("\n"),
        })
      }
    } catch (error: any) {
      if (isUserCancelled(error)) return
      await Dialog.alert({
        title: "导入失败",
        message: String(error?.message ?? error),
      })
    } finally {
      setLoadingMessage(null)
    }
  }, [isBusy])

  const addFromPhotos = useCallback(async () => {
    if (isBusy) return
    setLoadingMessage("正在导入照片...")
    try {
      const imported = await pickSourcesFromPhotos()
      if (imported.sources.length > 0) {
        setSources((prev) => {
          const start = getMaxSelectedOrder(prev) + 1
          return [...prev, ...assignSelectionOrderForImported(imported.sources, start)]
        })
      }
      if (imported.notices.length > 0) {
        await Dialog.alert({
          title: "导入提示",
          message: imported.notices.join("\n"),
        })
      }
    } catch (error: any) {
      if (isUserCancelled(error)) return
      await Dialog.alert({
        title: "导入失败",
        message: String(error?.message ?? error),
      })
    } finally {
      setLoadingMessage(null)
    }
  }, [isBusy])

  const setImportDirectory = useCallback(async () => {
    if (isBusy) return
    try {
      const directory = await chooseImportInitialDirectory()
      if (!directory) return
      await Dialog.alert({
        title: "默认导入路径已设置",
        message: directory,
      })
    } catch (error: any) {
      if (isUserCancelled(error)) return
      await Dialog.alert({
        title: "设置失败",
        message: String(error?.message ?? error),
      })
    }
  }, [isBusy])

  const deleteSelected = useCallback(async () => {
    if (!canDeleteSelected) return
    const ok = await Dialog.confirm({
      title: "删除选中项目",
      message: `确定删除当前选中的 ${selectedPages.length} 个项目吗？`,
    })
    if (!ok) return
    setSources((prev) =>
      compactSelectionOrders(
        prev
          .map((source) => ({
            ...source,
            pages: source.pages.filter((page) => !page.selected),
          }))
          .filter((source) => source.pages.length > 0)
      )
    )
  }, [canDeleteSelected, selectedPages.length])

  const deleteImportedPdfs = useCallback(async () => {
    if (isBusy || importedPdfSources.length === 0) return
    const ok = await Dialog.confirm({
      title: "删除已导入的 PDF",
      message: `确定删除当前已导入的 ${importedPdfSources.length} 个 PDF 项吗？`,
      confirmLabel: "删除",
      cancelLabel: "取消",
    })
    if (!ok) return
    setSources((prev) => compactSelectionOrders(prev.filter((source) => source.kind !== "pdf")))
  }, [importedPdfSources.length, isBusy])

  const deleteImportedPdfFiles = useCallback(async () => {
    if (isBusy || importedPdfFilePaths.length === 0) return
    const ok = await Dialog.confirm({
      title: "删除源 PDF 文件",
      message: `确定删除当前已导入项目对应的 ${importedPdfFilePaths.length} 个源 PDF 文件吗？此操作不可恢复。`,
      confirmLabel: "删除文件",
      cancelLabel: "取消",
    })
    if (!ok) return

    const removedPaths = new Set<string>()
    const failedPaths: string[] = []

    for (const pdfPath of importedPdfFilePaths) {
      try {
        const exists = await FileManager.exists(pdfPath)
        if (!exists) {
          removedPaths.add(pdfPath)
          continue
        }
        await FileManager.remove(pdfPath)
        removedPaths.add(pdfPath)
      } catch {
        failedPaths.push(pdfPath)
      }
    }

    if (removedPaths.size > 0) {
      setSources((prev) => removeSourcesByPdfPaths(prev, removedPaths))
    }

    if (failedPaths.length > 0) {
      await Dialog.alert({
        title: "部分删除失败",
        message: `已删除 ${removedPaths.size} 个文件，失败 ${failedPaths.length} 个。\n${failedPaths.join("\n")}`,
      })
      return
    }

    await Dialog.alert({
      title: "删除完成",
      message: `已删除 ${removedPaths.size} 个源 PDF 文件`,
    })
  }, [importedPdfFilePaths, isBusy])

  const runConvert = useCallback(async () => {
    if (!canConvert) return
    setProcessing(true)
    try {
      const result = await convertSelectedImagesToPdf(sources)
      setProcessing(false)
      await presentExportActionSheet(
        result.data,
        buildOutputFileName("images-converted"),
        `已转换 ${result.pageCount} 页图片`
      )
    } catch (error: any) {
      await Dialog.alert({
        title: "转换失败",
        message: String(error?.message ?? error),
      })
    } finally {
      setProcessing(false)
    }
  }, [canConvert, sources])

  const runMerge = useCallback(async () => {
    if (!canMerge) return
    setProcessing(true)
    try {
      const result = await mergeSelectedPagesToPdf(sources)
      setProcessing(false)
      await presentExportActionSheet(
        result.data,
        buildOutputFileName("merged-pdf"),
        `已合并 ${result.pageCount} 页`
      )
    } catch (error: any) {
      await Dialog.alert({
        title: "合并失败",
        message: String(error?.message ?? error),
      })
    } finally {
      setProcessing(false)
    }
  }, [canMerge, sources])

  return (
    <NavigationStack>
      <ZStack
        alignment="bottom"
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        background="systemGroupedBackground"
        ignoresSafeArea={{ edges: "bottom" }}
        navigationTitle="PDF Helper"
        navigationBarTitleDisplayMode="inline"
        toolbar={{
          topBarLeading: (
            <ZStack
              frame={{ width: 28, height: 28, alignment: "center" }}
              background={"rgba(0,0,0,0.001)"}
              contextMenu={{
                menuItems: (
                  <Group>
                    <Button
                      title="删除已导入的 PDF"
                      role="destructive"
                      disabled={isBusy || importedPdfSources.length === 0}
                      action={() => void deleteImportedPdfs()}
                    />
                    <Button
                      title="删除对应源 PDF 文件"
                      role="destructive"
                      disabled={isBusy || importedPdfFilePaths.length === 0}
                      action={() => void deleteImportedPdfFiles()}
                    />
                  </Group>
                ),
              }}
              onTapGesture={() => {
                if (deleteButtonDisabled) return
                if (canDeleteSelected) {
                  void deleteSelected()
                  return
                }
                void Dialog.alert({ message: "请先选择要删除的项目，或长按打开删除菜单" })
              }}
            >
              <Image
                systemName="trash"
                foregroundStyle="#DC2626"
                opacity={deleteButtonDisabled ? 0.45 : 1}
              />
            </ZStack>
          ),
          topBarTrailing: (
            <HStack spacing={8}>
              <Button
                title=""
                systemImage="folder"
                foregroundStyle={isBusy ? "secondaryLabel" : "systemBlue"}
                disabled={isBusy}
                action={() => void setImportDirectory()}
              />
              <Menu title="" systemImage="plus">
                <Button title="添加文件" systemImage="doc.badge.plus" action={() => void addFromFiles()} />
                <Button title="添加照片" systemImage="photo.on.rectangle.angled" action={() => void addFromPhotos()} />
              </Menu>
            </HStack>
          ),
        }}
      >
        <List
          listStyle="insetGroup"
          sheet={releaseNotesSheet}
          frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
          ignoresSafeArea={{ edges: "bottom" }}
        >
          {sources.length === 0 ? (
            <VStack spacing={8} padding={24}>
              <Text>点右上角「+」添加文件或照片</Text>
              <Text foregroundStyle="secondaryLabel">
                图片将显示整图；PDF 可按页导入或作为整体导入，支持自定义导入页码范围。当前版本不显示 PDF 页面缩略图
              </Text>
            </VStack>
          ) : (
            <Group>
              {sources.map((source) => (
                <SourceBlockView
                  key={source.id}
                  source={source}
                  onTogglePage={togglePage}
                  onDeletePage={deletePage}
                />
              ))}
              <VStack
                frame={{ height: 116 }}
                listRowBackground={<EmptyView />}
                listRowSeparator="hidden"
              />
            </Group>
          )}
        </List>

        <VStack
          padding={{ bottom: 8, leading: 18, trailing: 18 }}
          frame={{ maxWidth: "infinity", alignment: "bottom" as any }}
        >
          <VStack
            spacing={10}
            padding={{ top: 13, bottom: 12, leading: 18, trailing: 18 }}
            frame={{ maxWidth: "infinity", alignment: "leading" as any }}
            glassEffect={{ type: "rect", cornerRadius: 34 } as any}
          >
            <HStack>
              <Text foregroundStyle="secondaryLabel" font="footnote">
                已选择 {selectedPages.length} 项 · 共 {selectedTotalPageCount} 页（图片 {selectedImageCount}）
              </Text>
              <Spacer />
              {loadingMessage ? (
                <HStack spacing={6}>
                  <ProgressView progressViewStyle="circular" />
                  <Text font="footnote">{loadingMessage}</Text>
                </HStack>
              ) : null}
            </HStack>
            <HStack spacing={10}>
              <BottomActionButton
                title={processing ? "处理中..." : "转换"}
                systemImage="doc.badge.gearshape"
                disabled={!canConvert}
                action={() => void runConvert()}
              />
              <BottomActionButton
                title={processing ? "处理中..." : "合并"}
                systemImage="square.stack.3d.up.fill"
                disabled={!canMerge}
                action={() => void runMerge()}
              />
            </HStack>
          </VStack>
        </VStack>
      </ZStack>
    </NavigationStack>
  )
}
