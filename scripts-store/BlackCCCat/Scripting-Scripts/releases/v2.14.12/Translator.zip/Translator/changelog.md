## v2.14.12
- 修复Apple Intelligence无法正常翻译App Store长内容

## v2.14.10
- 支持sharesheet翻译
- 支持App Store翻译

## v2.14.9
- 优化翻译速度

## v2.14.1
- 迁移shared storage到脚本私有storage

## v2.13.3
- 全屏由`fullScreen`调整为`overFullScreen`，保持scripting脚本页面滚动状态
## 更早

- 更新说明页面适配低版本系统
- 新增脚本内翻译页面，可直接输入文本并按当前启用的引擎进行翻译。
- 新增更新内容提示，只有当本页内容发生变化时才会再次弹出。

## 说明

- 支持 System Translate、Apple Intelligence、Scripting Assistant、Google Translate。
- 支持添加 AI 接口与 DeepLX 引擎，并按自定义顺序显示结果。


