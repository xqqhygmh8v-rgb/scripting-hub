import {
  Button,
  ControlGroup,
  Divider,
  DragGesture,
  EmptyView,
  Editor,
  Group,
  GeometryReader,
  HStack,
  Image,
  Menu,
  MagnifyGesture,
  NavigationStack,
  Picker,
  Section,
  Script,
  Tab,
  TabView,
  Text,
  TextField,
  VStack,
  ZStack,
  useEffect,
  useObservable,
  useRef,
  useState,
  Form,
  Navigation,
  useColorScheme,
} from "scripting"

import type { CaisSettings, ClipboardClearRange, ClipGroup, ClipItem, ClipKind, ClipKindCountsByScope, ClipListScope, KeyboardCustomAction, KeyboardMenuBuiltinAction, MonitorStatus } from "../types"
import { captureCurrentClipboard, startClipboardMonitor, stopClipboardMonitor } from "../services/clipboard_capture"
import { currentChangeCount, writeClipToPasteboard, writeImageToPasteboard, writeTextToPasteboard } from "../services/pasteboard_adapter"
import {
  addClipFromPayload,
  clearClipboardClipsByRange,
  clearFavoriteClips,
  editClipContent,
  getClipGroups,
  getClipKindCounts,
  getFullClipContent,
  markCopied,
  softDeleteClip,
  toggleFavorite,
  togglePinned,
  updateClipTitle,
  addFavoriteFromInput,
} from "../storage/clip_repository"
import { initializeDatabase, readDatabaseDataVersion } from "../storage/database"
import { readClipDataVersion, subscribeClipDataChanges } from "../storage/change_signal"
import { loadSettings, saveSettings } from "../storage/settings_store"
import { applyICloudSyncSettings } from "../storage/icloud_sync"
import { formatDateTime, withHaptic } from "../utils/common"
import { renderRuntimeTemplate } from "../utils/template"
import { readAppFullscreen, writeAppFullscreen } from "../utils/window_state"
import { ClipRow, NonGlassClipRow } from "./ClipRow"
import { PipStatusView } from "./PipStatusView"
import { useReleaseNotesSheet } from "./ReleaseNotesSheet"
import { SettingsView } from "./SettingsView"
import { TokenSelectionPanel } from "./TokenSelectionPanel"
import { readPipControlState, writePipControlState } from "../services/pip_control"
import { selectedTokenText, tokenizeWords, type CaisToken } from "../utils/tokenize"
import {
  applyBuiltinMenuAction,
  applyCustomMenuAction,
  customActionSystemImage,
  getOrderedMenuBuiltins,
  menuBuiltinSystemImage,
  menuBuiltinTitle,
  type MenuActionResult,
} from "../utils/menu_actions"
import { clearCurrentClipboardIfMatchesDeletedItem } from "../services/clipboard_cleanup"
import {
  getLanShareRuntimeStatus,
  reconcileLanShareServer,
  releaseLanShareServer,
  type LanShareRuntimeStatus,
} from "../services/lan_share_server"
import { rotateLanShareAccessToken } from "../services/lan_share_credentials"
import { recognizeTextFromImagePath } from "../services/image_text_recognition"

const TAB_FAVORITES = 0
const TAB_CLIPS = 1
const TAB_SETTINGS = 2
const APP_GROUP_PAGE_SIZE = 300
const TOAST_DURATION_MS = 1200
const CAIS_APP_RESUME_HANDLER = "__CAIS_APP_RESUME_HANDLER__"
const APP_SCROLL_CONTENT_MARGINS = {
  insets: { top: 0, bottom: 0, leading: 0, trailing: 0 },
  placement: "scrollContent" as const,
}
type ClearScope = "favorites" | ClipboardClearRange
let intentionalMinimize = false
let appRefreshGeneration = 0
let appMonitorStopper: (() => void) | null = null
type AppRootMode = "app" | "home"
type ClipKindFilter = ClipKind | null
const EMPTY_CLIP_KIND_COUNTS: ClipKindCountsByScope = {
  favorites: { total: 0, text: 0, url: 0, image: 0 },
  clipboard: { total: 0, text: 0, url: 0, image: 0 },
}

function renderClipOutput(item: ClipItem, content: string): string {
  return item.manualFavorite ? renderRuntimeTemplate(content) : content
}

function EmptyState(props: {
  title: string
  message: string
  systemImage: string
}) {
  const colorScheme = useColorScheme()
  const cardFill = colorScheme === "dark" ? "secondarySystemBackground" : "systemBackground"

  return (
    <HStack
      frame={{ maxWidth: "infinity", alignment: "center" as any }}
      listRowInsets={{ top: 5, bottom: 5, leading: 12, trailing: 12 }}
      listRowSeparator="hidden"
      listRowBackground={<EmptyView />}
    >
      <VStack
        frame={{ maxWidth: "infinity", alignment: "center" as any }}
        padding={{ top: 40, bottom: 40, leading: 16, trailing: 16 }}
        spacing={12}
        background={{ style: cardFill, shape: { type: "rect", cornerRadius: 18 } }}
        glassEffect={{ type: "rect", cornerRadius: 18 } as any}
        shadow={{
          color: colorScheme === "dark" ? "rgba(0,0,0,0.20)" : "rgba(0,0,0,0.07)",
          radius: 10,
          y: 4,
        }}
      >
        <Image systemName={props.systemImage} font="largeTitle" foregroundStyle="secondaryLabel" />
        <Text font="headline">{props.title}</Text>
        <Text foregroundStyle="secondaryLabel" multilineTextAlignment="center">{props.message}</Text>
      </VStack>
    </HStack>
  )
}

function AddFavoriteView() {
  const dismiss = Navigation.useDismiss()
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  return (
    <NavigationStack>
      <Form
        navigationTitle="添加收藏"
        navigationBarTitleDisplayMode="inline"
        formStyle="grouped"
        presentationDetents={[0.72, "large"]}
        presentationDragIndicator="visible"
        toolbar={{
          topBarLeading: <Button title="取消" role="cancel" action={() => dismiss(null)} />,
          topBarTrailing: <Button title="保存" disabled={!content.trim()} action={() => {
            dismiss({ title, content })
          }} />
        }}
      >
        <Section>
          <TextField title="标题" value={title} prompt="可选，留空则自动生成" onChanged={setTitle} />
        </Section>
        <Section
          header={<Text>内容</Text>}
          footer={<Text>{"可使用 {{text}}、{{date}}、{{time}}、{{datetime}}、{{timestamp}}。"}</Text>}
        >
          <TextField
            title=""
            value={content}
            prompt="输入你想收藏的内容"
            axis="vertical"
            frame={{ minHeight: 120, maxWidth: "infinity", alignment: "topLeading" as any }}
            onChanged={setContent}
          />
        </Section>
      </Form>
    </NavigationStack>
  )
}

function ClipContentEditorView(props: {
  content: string
}) {
  const dismiss = Navigation.useDismiss()
  const [controller] = useState(() => new EditorController({
    content: props.content,
    ext: "txt",
    readOnly: false,
  }))

  useEffect(() => {
    return () => {
      controller.dispose()
    }
  }, [controller])

  return (
    <NavigationStack>
      <VStack
        navigationTitle="编辑内容"
        navigationBarTitleDisplayMode="inline"
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        presentationDetents={["large"]}
        presentationDragIndicator="visible"
        toolbar={{
          topBarLeading: <Button title="取消" role="cancel" action={() => dismiss(null)} />,
          topBarTrailing: <Button title="保存" action={() => dismiss(controller.content)} />,
        }}
      >
        <Editor
          controller={controller}
          scriptName="CAIS"
          showAccessoryView
          searchEnabled
          ignoresSafeArea={{ regions: "container", edges: "bottom" }}
        />
      </VStack>
    </NavigationStack>
  )
}

function AppTokenResultView(props: {
  tokens: CaisToken[]
}) {
  const dismiss = Navigation.useDismiss()
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  const selectedText = selectedTokenText(props.tokens, selectedIds)

  function toggleToken(token: CaisToken) {
    setSelectedIds((ids) => ids.includes(token.id)
      ? ids.filter((id) => id !== token.id)
      : [...ids, token.id])
  }

  return (
    <NavigationStack>
      <VStack
        navigationTitle="分词结果"
        navigationBarTitleDisplayMode="inline"
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        padding={16}
        toolbar={{
          topBarLeading: <Button title="清空" systemImage="arrow.counterclockwise.circle" disabled={!selectedText} action={() => setSelectedIds([])} />,
          topBarTrailing: <Button title="复制" systemImage="doc.on.doc" disabled={!selectedText} action={() => dismiss(selectedText)} />,
        }}
      >
        <TokenSelectionPanel
          tokens={props.tokens}
          selectedIds={selectedIds}
          selectedText={selectedText}
          minHeight={420}
          onToggle={toggleToken}
        />
      </VStack>
    </NavigationStack>
  )
}

function ImageViewerView(props: {
  item: ClipItem
}) {
  const dismiss = Navigation.useDismiss()
  const imagePath = props.item.imagePath
  const [scale, setScale] = useState(1)
  const [offset, setOffset] = useState({ x: 0, y: 0 })
  const gestureBaseScale = useRef(1)
  const gestureBaseOffset = useRef({ x: 0, y: 0 })
  const [imageSize] = useState(() => {
    const image = imagePath ? UIImage.fromFile(imagePath) : null
    return image ? { width: image.width, height: image.height } : null
  })

  function zoomScale(magnification: number): number {
    return Math.max(1, Math.min(5, gestureBaseScale.current * magnification))
  }

  function constrainedOffset(
    value: { x: number; y: number },
    zoom: number,
    viewport: { width: number; height: number },
  ) {
    const viewportWidth = Math.max(1, viewport.width)
    const viewportHeight = Math.max(1, viewport.height)
    let fittedWidth = viewportWidth
    let fittedHeight = viewportHeight
    if (imageSize?.width && imageSize.height) {
      const fit = Math.min(viewportWidth / imageSize.width, viewportHeight / imageSize.height)
      fittedWidth = imageSize.width * fit
      fittedHeight = imageSize.height * fit
    }
    const maxX = Math.max(0, (fittedWidth * zoom - viewportWidth) / 2)
    const maxY = Math.max(0, (fittedHeight * zoom - viewportHeight) / 2)
    return {
      x: Math.max(-maxX, Math.min(maxX, value.x)),
      y: Math.max(-maxY, Math.min(maxY, value.y)),
    }
  }

  function magnifiedOffset(
    magnification: number,
    location: { x: number; y: number },
    viewport: { width: number; height: number },
  ) {
    const nextScale = zoomScale(magnification)
    const ratio = nextScale / gestureBaseScale.current
    const base = gestureBaseOffset.current
    return constrainedOffset({
      x: base.x * ratio + (location.x - viewport.width / 2) * (1 - ratio),
      y: base.y * ratio + (location.y - viewport.height / 2) * (1 - ratio),
    }, nextScale, viewport)
  }

  return (
    <NavigationStack>
      <VStack
        navigationTitle={props.item.title || "图片"}
        navigationBarTitleDisplayMode="inline"
        frame={{ maxWidth: "infinity", maxHeight: "infinity", alignment: "center" as any }}
        padding={16}
        toolbar={{
          topBarTrailing: <Button title="完成" action={() => dismiss(null)} />,
        }}
      >
        {imagePath ? (
          <GeometryReader>
            {(proxy) => (
              <ZStack
                frame={{ width: proxy.size.width, height: proxy.size.height, alignment: "center" as any }}
                clipped
                gesture={
                  MagnifyGesture(0.01)
                    .onChanged((value) => {
                      const nextScale = zoomScale(value.magnification)
                      setScale(nextScale)
                      setOffset(magnifiedOffset(value.magnification, value.startLocation, proxy.size))
                    })
                    .onEnded((value) => {
                      const nextScale = zoomScale(value.magnification)
                      const nextOffset = magnifiedOffset(value.magnification, value.startLocation, proxy.size)
                      gestureBaseScale.current = nextScale
                      gestureBaseOffset.current = nextOffset
                      setScale(nextScale)
                      setOffset(nextOffset)
                    })
                }
                simultaneousGesture={
                  DragGesture({ minDistance: 2, coordinateSpace: "local" })
                    .onChanged((value) => {
                      if (scale <= 1) return
                      setOffset(constrainedOffset({
                        x: gestureBaseOffset.current.x + value.translation.width,
                        y: gestureBaseOffset.current.y + value.translation.height,
                      }, scale, proxy.size))
                    })
                    .onEnded((value) => {
                      if (scale <= 1) {
                        gestureBaseOffset.current = { x: 0, y: 0 }
                        setOffset({ x: 0, y: 0 })
                        return
                      }
                      const nextOffset = constrainedOffset({
                        x: gestureBaseOffset.current.x + value.translation.width,
                        y: gestureBaseOffset.current.y + value.translation.height,
                      }, scale, proxy.size)
                      gestureBaseOffset.current = nextOffset
                      setOffset(nextOffset)
                    })
                }
              >
                <ZStack
                  scaleEffect={scale}
                  offset={offset}
                  frame={{ width: proxy.size.width, height: proxy.size.height, alignment: "center" as any }}
                >
                  <Image
                    filePath={imagePath}
                    resizable
                    scaleToFit
                    frame={{ width: proxy.size.width, height: proxy.size.height, alignment: "center" as any }}
                  />
                </ZStack>
              </ZStack>
            )}
          </GeometryReader>
        ) : (
          <Text foregroundStyle="secondaryLabel">图片文件不可读取</Text>
        )}
      </VStack>
    </NavigationStack>
  )
}

export function AppRoot(props: { mode?: AppRootMode } = {}) {
  const mode = props.mode ?? "app"
  const homeScreenMode = mode === "home"
  const releaseNotesSheet = useReleaseNotesSheet({
    title: "CAIS 更新说明",
    detents: ["medium", "large"],
    // Legacy identifier retained so renaming the Markdown file does not reset read state.
    storageKey: "cais:release-notes:release-notes.md:last-seen-hash",
  })
  const colorScheme = useColorScheme()
  const activeTab = useObservable(TAB_CLIPS)
  const pipPresented = useObservable(false)
  const deleteDialogPresented = useObservable(false)
  const toastPresented = useObservable(false)
  const [settings, setSettings] = useState<CaisSettings>(() => loadSettings())
  const [favoriteGroups, setFavoriteGroups] = useState<ClipGroup[]>([])
  const [clipboardGroups, setClipboardGroups] = useState<ClipGroup[]>([])
  const [clipKindCounts, setClipKindCounts] = useState<ClipKindCountsByScope>(EMPTY_CLIP_KIND_COUNTS)
  const [clipKindFilters, setClipKindFilters] = useState<Record<ClipListScope, ClipKindFilter>>({ favorites: null, clipboard: null })
  const [homeInitialDataReady, setHomeInitialDataReady] = useState(!homeScreenMode)
  const [pendingDeleteItem, setPendingDeleteItem] = useState<ClipItem | null>(null)
  const [pendingDeleteTab, setPendingDeleteTab] = useState<number | null>(null)
  const [query, setQuery] = useState("")
  const settingsRef = useRef(settings)
  const queryRef = useRef(query)
  const clipKindFiltersRef = useRef(clipKindFilters)
  const lastObservedPasteboardChangeCount = useRef<number | null>(null)
  const toastHideTimer = useRef<any>(null)
  const [appFullscreen, setAppFullscreen] = useState(() => readAppFullscreen(false))
  const [loading, setLoading] = useState(false)
  const [toastMessage, setToastMessage] = useState("")
  const [lanShareStatus, setLanShareStatus] = useState<LanShareRuntimeStatus>(() => getLanShareRuntimeStatus(settings))
  const lanShareStatusRef = useRef(lanShareStatus)
  const [monitorStatus, setMonitorStatus] = useState<MonitorStatus>({
    active: false,
    lastMessage: "未启动",
    capturedCount: 0,
  })
  const cardFill = colorScheme === "dark" ? "secondarySystemBackground" : "systemBackground"

  useEffect(() => {
    settingsRef.current = settings
  }, [settings])

  useEffect(() => {
    queryRef.current = query
  }, [query])

  useEffect(() => {
    deleteDialogPresented.setValue(false)
    setPendingDeleteItem(null)
    setPendingDeleteTab(null)
  }, [activeTab.value])

  useEffect(() => {
    const previousResumeHandler = (globalThis as any)[CAIS_APP_RESUME_HANDLER]
    ;(globalThis as any)[CAIS_APP_RESUME_HANDLER] = handleScriptResume
    void boot()
    const removeMinimize = homeScreenMode ? undefined : Script.onMinimize?.(() => {
      if (intentionalMinimize) {
        intentionalMinimize = false
        return
      }
      Script.exit()
    })
    return () => {
      if (previousResumeHandler) {
        ;(globalThis as any)[CAIS_APP_RESUME_HANDLER] = previousResumeHandler
      } else {
        delete (globalThis as any)[CAIS_APP_RESUME_HANDLER]
      }
      removeMinimize?.()
      clearToastHideTimer()
      stopPipMonitor()
    }
  }, [])

  useEffect(() => {
    let lastSeenCommandAt = 0
    const timer = (globalThis as any).setInterval?.(() => {
      const state = readPipControlState()
      if (!state.command || state.updatedAt <= lastSeenCommandAt) return
      lastSeenCommandAt = state.updatedAt
      if (state.command === "stop") {
        deactivatePipFromExternal()
      } else if (state.command === "start") {
        void activatePipFromApp()
      }
    }, 500)
    return () => {
      if (timer) (globalThis as any).clearInterval?.(timer)
    }
  }, [])

  useEffect(() => {
    let stopped = false
    let lastSeenClipDataVersion = readClipDataVersion()
    let lastSeenDatabaseDataVersion: number | null = null
    let checkingDatabaseDataVersion = false
    let refreshQueued = false
    let refreshRequested = false
    let socket: WebSocket | null = null
    let socketKey = ""

    function scheduleRefresh() {
      if (stopped) return
      if (refreshQueued) {
        refreshRequested = true
        return
      }
      refreshQueued = true
      const run = () => {
        if (stopped) {
          refreshQueued = false
          return
        }
        void refresh(true, settingsRef.current).catch(() => {}).finally(() => {
          refreshQueued = false
          if (refreshRequested) {
            refreshRequested = false
            scheduleRefresh()
          }
        })
      }
      if ((globalThis as any).setTimeout) {
        ;(globalThis as any).setTimeout(run, 0)
      } else {
        run()
      }
    }

    function refreshForVersion(version: number) {
      if (version <= lastSeenClipDataVersion) return
      lastSeenClipDataVersion = version
      scheduleRefresh()
    }

    function checkDatabaseVersion() {
      if (checkingDatabaseDataVersion) return
      checkingDatabaseDataVersion = true
      void readDatabaseDataVersion().then((version) => {
        if (stopped) return
        if (lastSeenDatabaseDataVersion != null && version !== lastSeenDatabaseDataVersion) {
          scheduleRefresh()
        }
        lastSeenDatabaseDataVersion = version
      }).catch(() => {}).finally(() => {
        checkingDatabaseDataVersion = false
      })
    }

    function closeSocket() {
      const current = socket
      socket = null
      socketKey = ""
      try { current?.close() } catch {}
    }

    function connectSocket() {
      if (stopped) return
      const status = lanShareStatusRef.current
      if (status.state !== "running" && status.state !== "delegated") {
        closeSocket()
        return
      }
      if (typeof WebSocket !== "function") return
      const key = `${status.port}:${status.accessCode}`
      if (socket && socketKey === key) return
      closeSocket()
      try {
        const next = new WebSocket(`ws://127.0.0.1:${status.port}/ws?token=${encodeURIComponent(status.accessCode)}`)
        socket = next
        socketKey = key
        next.onmessage = (message) => {
          if (stopped) return
          try {
            const raw = typeof message === "string" ? message : message.toRawString("utf-8") ?? ""
            const value = JSON.parse(raw)
            if (value?.type === "connected" || value?.type === "dataChanged") {
              refreshForVersion(Number(value.version) || 0)
            }
          } catch {
          }
        }
        next.onerror = () => {
          try { next.close() } catch {}
        }
        next.onclose = () => {
          if (socket === next) {
            socket = null
            socketKey = ""
          }
        }
      } catch {
        closeSocket()
      }
    }

    const unsubscribe = subscribeClipDataChanges(refreshForVersion)
    const timer = (globalThis as any).setInterval?.(() => {
      checkDatabaseVersion()
      connectSocket()
    }, 700)
    return () => {
      stopped = true
      unsubscribe()
      closeSocket()
      if (timer) (globalThis as any).clearInterval?.(timer)
    }
  }, [])

  useEffect(() => {
    let stopped = false
    let reconciling = false

    async function reconcile() {
      if (stopped || reconciling) return
      reconciling = true
      try {
        const latest = loadSettings()
        const current = settingsRef.current
        if (
          latest.lanSharingEnabled !== current.lanSharingEnabled ||
          latest.lanSharingPort !== current.lanSharingPort
        ) {
          const merged = {
            ...current,
            lanSharingEnabled: latest.lanSharingEnabled,
            lanSharingPort: latest.lanSharingPort,
          }
          settingsRef.current = merged
          if (!stopped) setSettings(merged)
        }
        const status = await reconcileLanShareServer(latest)
        if (!stopped) publishLanShareStatus(status)
      } finally {
        reconciling = false
      }
    }

    void reconcile()
    const timer = (globalThis as any).setInterval?.(() => void reconcile(), 1500)
    return () => {
      stopped = true
      if (timer) (globalThis as any).clearInterval?.(timer)
      releaseLanShareServer()
    }
  }, [])

  useEffect(() => {
    let stopped = false
    let checking = false
    let timer: any = null

    function schedule() {
      if (stopped) return
      const interval = Math.max(300, settingsRef.current.monitorIntervalMs || 500)
      timer = (globalThis as any).setTimeout?.(tick, interval)
    }

    function tick() {
      if (stopped) return
      if (checking) {
        schedule()
        return
      }
      checking = true
      void (async () => {
        try {
          await captureClipboardChangeAndRefresh()
        } finally {
          checking = false
          schedule()
        }
      })()
    }

    timer = (globalThis as any).setTimeout?.(tick, 500)
    return () => {
      stopped = true
      if (timer) (globalThis as any).clearTimeout?.(timer)
    }
  }, [])

  useEffect(() => {
    const timer = (globalThis as any).setTimeout?.(() => {
      void refresh(true)
    }, 180)
    return () => {
      if (timer) (globalThis as any).clearTimeout?.(timer)
    }
  }, [query])

  async function boot() {
    setLoading(true)
    try {
      await initializeDatabase()
      await captureClipboardAndRefresh(settingsRef.current, true)
      if (Script.queryParameters?.pip === "1") {
        await activatePipFromApp()
      }
    } catch {
      if (homeScreenMode) setHomeInitialDataReady(true)
    } finally {
      setLoading(false)
    }
  }

  async function captureClipboardAndRefresh(currentSettings = settingsRef.current, force = false) {
    await captureClipboardIfChanged(currentSettings, force)
    await refresh(true, currentSettings)
  }

  async function captureClipboardChangeAndRefresh() {
    if (pipPresented.value || appMonitorStopper) return
    const changed = await captureClipboardIfChanged(settingsRef.current)
    if (changed) {
      await refresh(true, settingsRef.current)
    }
  }

  async function captureClipboardIfChanged(currentSettings = settingsRef.current, force = false): Promise<boolean> {
    try {
      const changeCount = await currentChangeCount()
      if (!force && lastObservedPasteboardChangeCount.current === changeCount) return false
      lastObservedPasteboardChangeCount.current = changeCount
      const result = await captureCurrentClipboard(currentSettings)
      return result.status === "created" || result.status === "updated"
    } catch {
      return false
    }
  }

  function handleScriptResume(details: any = {}) {
    if (details.resumeFromMinimized) {
      intentionalMinimize = false
    }
    const pipCommand = details.queryParameters?.pip
    if (pipCommand === "0") {
      deactivatePipFromExternal({ exitAfter: true })
      return
    }
    if (pipCommand === "1") {
      void activatePipFromApp()
      return
    }
    void captureClipboardChangeAndRefresh()
  }

  async function refresh(_force = false, currentSettings = settings) {
    const generation = ++appRefreshGeneration
    const groupLimit = Math.min(currentSettings.maxItems, APP_GROUP_PAGE_SIZE)
    const search = queryRef.current.trim()
    const filters = clipKindFiltersRef.current
    const [nextFavoriteGroups, nextClipboardGroups, nextClipKindCounts] = await Promise.all([
      getClipGroups("favorites", search, groupLimit, 0, filters.favorites ?? undefined),
      getClipGroups("clipboard", search, groupLimit, 0, filters.clipboard ?? undefined),
      getClipKindCounts(),
    ])
    if (generation !== appRefreshGeneration) return
    setFavoriteGroups(nextFavoriteGroups)
    setClipboardGroups(nextClipboardGroups)
    setClipKindCounts(nextClipKindCounts)
    if (homeScreenMode) setHomeInitialDataReady(true)
  }

  async function updateSettings(nextSettings: CaisSettings) {
    const previous = settingsRef.current
    const needsStorageMigration =
      previous.iCloudSync !== nextSettings.iCloudSync ||
      previous.iCloudSyncImages !== nextSettings.iCloudSyncImages
    try {
      if (needsStorageMigration) await applyICloudSyncSettings(previous, nextSettings)
      const next = saveSettings(nextSettings)
      settingsRef.current = next
      setSettings(next)
      if (
        previous.lanSharingEnabled !== next.lanSharingEnabled ||
        previous.lanSharingPort !== next.lanSharingPort
      ) {
        publishLanShareStatus(await reconcileLanShareServer(next))
      }
      void refresh(true, next)
    } catch (error: any) {
      await Dialog.alert({
        title: "iCloud 同步失败",
        message: String(error?.message ?? error ?? "数据迁移失败"),
      })
    }
  }

  function clearToastHideTimer() {
    if (toastHideTimer.current) {
      ;(globalThis as any).clearTimeout?.(toastHideTimer.current)
      toastHideTimer.current = null
    }
  }

  function showToast(message: string) {
    clearToastHideTimer()
    setToastMessage(message)
    toastPresented.setValue(false)
    ;(globalThis as any).setTimeout?.(() => {
      toastPresented.setValue(true)
    }, 0)
    toastHideTimer.current = (globalThis as any).setTimeout?.(() => {
      toastPresented.setValue(false)
      toastHideTimer.current = null
    }, TOAST_DURATION_MS)
  }

  function publishLanShareStatus(status: LanShareRuntimeStatus) {
    const current = lanShareStatusRef.current
    if (
      current.state === status.state &&
      current.port === status.port &&
      current.address === status.address &&
      current.accessUrl === status.accessUrl &&
      current.accessCode === status.accessCode &&
      current.message === status.message
    ) return
    lanShareStatusRef.current = status
    setLanShareStatus(status)
  }

  async function rotateLanShareToken() {
    rotateLanShareAccessToken()
    publishLanShareStatus(await reconcileLanShareServer(settingsRef.current))
    showToast("访问码已更新")
  }

  function toastOptions() {
    return {
      isPresented: toastPresented,
      message: toastMessage,
      duration: TOAST_DURATION_MS / 1000,
      position: "bottom" as any,
    }
  }

  async function captureNow() {
    setLoading(true)
    try {
      const result = await captureCurrentClipboard(settings)
      const message =
        result.status === "created" ? `已采集：${result.item.title}` :
        result.status === "updated" ? `已更新：${result.item.title}` :
        result.reason
      showToast(message)
      await refresh()
    } catch {
    } finally {
      setLoading(false)
    }
  }

  async function copyItem(item: ClipItem) {
    try {
      const fullContent = renderClipOutput(item, await getFullClipContent(item.id))
      await writeClipToPasteboard(item, fullContent)
      await markCopied(item)
      showToast("已复制")
      await refresh()
    } catch (error: any) {
      await Dialog.alert({ message: String(error?.message ?? error ?? "复制失败") })
    }
  }

  function requestDeleteItem(item: ClipItem) {
    setPendingDeleteItem(item)
    setPendingDeleteTab(activeTab.value)
    deleteDialogPresented.setValue(true)
  }

  function dismissDeleteDialog() {
    deleteDialogPresented.setValue(false)
    setPendingDeleteItem(null)
    setPendingDeleteTab(null)
  }

  async function confirmDeleteItem() {
    const item = pendingDeleteItem
    dismissDeleteDialog()
    if (!item) return
    await clearCurrentClipboardIfMatchesDeletedItem(item)
    await softDeleteClip(item)
    await refresh()
  }

  async function requestClear(scope: ClearScope) {
    const ok = await Dialog.confirm({
      title: `清空${clearScopeLabel(scope)}？`,
      message: "此操作无法撤销。",
      cancelLabel: "取消",
      confirmLabel: "清空",
    })
    if (!ok) return
    await clearData(scope)
  }

  function clearScopeLabel(scope: ClearScope): string {
    switch (scope) {
      case "favorites": return "收藏数据"
      case "recent": return "最近内容"
      case "threeDays": return "近三天剪贴板数据"
      case "sevenDays": return "近七天剪贴板数据"
      case "older": return "更早剪贴板数据"
    }
  }

  async function clearData(scope: ClearScope) {
    showToast("正在删除...")
    // Yield to let toast render before blocking on async work
    await new Promise((r) => (globalThis as any).setTimeout?.(r, 50))
    if (scope === "favorites") {
      await clearFavoriteClips()
      showToast("已清空收藏数据")
    } else {
      await clearClipboardClipsByRange(scope)
      showToast("已清空剪贴板数据")
    }
    await refresh()
  }

  async function editItemTitle(item: ClipItem) {
    const title = await Dialog.prompt({
      title: "增加标题",
      message: "留空时继续使用正文内容作为标题。",
      defaultValue: item.title,
      placeholder: "输入标题",
      cancelLabel: "取消",
      confirmLabel: "保存",
      selectAll: true,
    })
    if (title == null) return
    await updateClipTitle(item, title)
    await refresh()
  }

  async function editItem(item: ClipItem) {
    if (item.kind === "image") {
      await Dialog.alert({ message: "图片条目暂不支持编辑文本内容" })
      return
    }
    const fullContent = await getFullClipContent(item.id)
    const initialChangeCount = await currentChangeCount()
    try {
      const nextContent = await Navigation.present<string | null>({
        element: <ClipContentEditorView content={fullContent} />,
        modalPresentationStyle: "pageSheet",
      })
      let needsRefresh = false
      if (await currentChangeCount() !== initialChangeCount) {
        await captureCurrentClipboard(settings)
        needsRefresh = true
      }
      if (nextContent != null && nextContent !== fullContent) {
        await editClipContent(item, nextContent)
        needsRefresh = true
      }
      if (needsRefresh) await refresh()
    } catch (error: any) {
      await Dialog.alert({ message: String(error?.message ?? error ?? "编辑失败") })
    }
  }

  async function viewImageItem(item: ClipItem) {
    await Navigation.present({
      element: <ImageViewerView item={item} />,
      modalPresentationStyle: "pageSheet",
    })
  }

  async function extractTextFromImage(item: ClipItem) {
    try {
      showToast("正在提取文字...")
      const text = await recognizeTextFromImagePath(item.imagePath)
      if (!text) {
        showToast("未识别到文字")
        return
      }
      await writeTextToPasteboard(text)
      await addClipFromPayload(
        { kind: "text", text },
        { ...settingsRef.current, captureText: true },
      )
      showToast("已提取文字并复制")
      await refresh()
    } catch (error: any) {
      await Dialog.alert({ message: String(error?.message ?? error ?? "文字提取失败") })
    }
  }

  async function shareItem(item: ClipItem) {
    try {
      const value = item.kind === "image" ? item.imagePath : await itemSource(item)
      if (!value) {
        showToast("当前条目无法分享")
        return
      }
      await ShareSheet.present([value])
    } catch (error: any) {
      await Dialog.alert({ message: String(error?.message ?? error ?? "分享失败") })
    }
  }

  async function itemSource(item: ClipItem): Promise<string> {
    if (item.kind === "image") return ""
    return renderClipOutput(item, await getFullClipContent(item.id))
  }

  async function openTokenResultForItem(item: ClipItem) {
    if (item.kind === "image") {
      showToast("图片条目不支持分词")
      return
    }
    try {
      const source = await itemSource(item)
      const tokens = tokenizeWords(source)
      if (!tokens.length) {
        showToast("没有可用的分词结果")
        return
      }
      const result = await Navigation.present<string | null>({
        element: <AppTokenResultView tokens={tokens} />,
        modalPresentationStyle: "pageSheet",
      })
      if (!result) return
      await writeTextToPasteboard(result)
      await addClipFromPayload(
        { kind: "text", text: result },
        { ...settingsRef.current, captureText: true },
      )
      showToast("已复制")
      await refresh()
    } catch (error: any) {
      await Dialog.alert({ message: String(error?.message ?? error ?? "分词失败") })
    }
  }

  async function saveTransformedResult(result: MenuActionResult, source: string): Promise<number> {
    const saveSettings = { ...settingsRef.current, captureText: true, captureImages: true }
    if (result.kind === "text") {
      if (!result.text.trim() || result.text === source) return 0
      const saved = await addClipFromPayload({ kind: "text", text: result.text }, saveSettings)
      return saved.status !== "skipped" ? 1 : 0
    }
    if (result.kind === "texts") {
      let savedCount = 0
      for (const text of result.texts) {
        if (!text.trim() || text === source) continue
        const saved = await addClipFromPayload({ kind: "text", text }, saveSettings)
        if (saved.status !== "skipped") savedCount += 1
      }
      return savedCount
    }
    if (result.kind === "image") {
      const saved = await addClipFromPayload({
        kind: "image",
        image: result.image,
        imageContentHash: result.imageContentHash,
      }, saveSettings)
      return saved.status !== "skipped" ? 1 : 0
    }
    return 0
  }

  async function copyMenuResult(result: MenuActionResult, source: string) {
    if (result.kind === "openUrl") {
      await Safari.openURL(result.url)
      return
    }
    if (result.kind === "none") {
      showToast(result.message ?? "没有返回内容")
      return
    }
    if (result.kind === "texts") {
      const saved = await saveTransformedResult(result, source)
      showToast(saved ? `已拆分保存 ${saved} 条` : "没有新的拆分结果")
      await refresh()
      return
    }
    if (result.kind === "text") {
      const shouldCopy = result.writeToClipboard !== false
      if (shouldCopy) await writeTextToPasteboard(result.text)
      const saved = await saveTransformedResult(result, source)
      showToast(saved ? (shouldCopy ? "已复制并保存" : "已保存") : (shouldCopy ? "已复制" : "已完成"))
      await refresh()
      return
    } else {
      await writeImageToPasteboard(result.image)
    }
    const saved = await saveTransformedResult(result, source)
    showToast(saved ? "已复制并保存" : "已复制")
    await refresh()
  }

  async function runBuiltinActionForItem(item: ClipItem, action: KeyboardMenuBuiltinAction) {
    try {
      const source = await itemSource(item)
      const result = applyBuiltinMenuAction({
        action,
        source,
        imagePath: item.imagePath,
        isImage: item.kind === "image",
      })
      if (!result) {
        showToast("当前条目不支持该功能")
        return
      }
      await copyMenuResult(result, source)
    } catch (error: any) {
      await Dialog.alert({ message: String(error?.message ?? error ?? `${menuBuiltinTitle(action)}失败`) })
    }
  }

  async function runCustomActionForItem(item: ClipItem, action: KeyboardCustomAction) {
    if (item.kind === "image") {
      showToast("当前条目不支持该自定义功能")
      return
    }
    try {
      const source = await itemSource(item)
      const result = await applyCustomMenuAction(action, source)
      if (!result) {
        showToast("当前条目不支持该自定义功能")
        return
      }
      await copyMenuResult(result, source)
    } catch (error: any) {
      await Dialog.alert({ message: String(error?.message ?? error ?? "自定义功能执行失败") })
    }
  }

  function startPipMonitor() {
    const status = { active: true, lastMessage: "监听启动中", lastCheckedAt: Date.now(), capturedCount: 0 }
    setMonitorStatus(status)
    writePipControlState({ active: true, command: undefined })
    if (appMonitorStopper) return
    appMonitorStopper = startClipboardMonitor(settings, (next) => {
      setMonitorStatus(next)
      if (next.lastCapturedAt) {
        showToast(next.lastMessage)
        void refresh()
      }
    })
  }

  function stopPipMonitor() {
    if (appMonitorStopper) {
      appMonitorStopper()
      appMonitorStopper = null
    } else {
      stopClipboardMonitor()
    }
    setMonitorStatus({ active: false, lastMessage: "监听已停止", lastCheckedAt: Date.now(), capturedCount: 0 })
    writePipControlState({ active: false, command: undefined })
  }

  function togglePip() {
    const next = !pipPresented.value
    pipPresented.setValue(next)
    if (next) {
      startPipMonitor()
    } else {
      stopPipMonitor()
    }
  }

  function deactivatePipFromExternal(options: { exitAfter?: boolean } = {}) {
    pipPresented.setValue(false)
    stopPipMonitor()
    if (options.exitAfter && !homeScreenMode) {
      ;(globalThis as any).setTimeout?.(() => {
        Script.exit()
      }, 250)
    }
  }

  async function minimizeScript() {
    if (!Script.supportsMinimization?.()) {
      return
    }
    try {
      intentionalMinimize = true
      const ok = await Script.minimize()
      if (!ok) intentionalMinimize = false
    } catch (error: any) {
      intentionalMinimize = false
      await Dialog.alert({ message: String(error?.message ?? error ?? "最小化失败") })
    }
  }

  function toggleFullscreenMode() {
    const next = !appFullscreen
    setAppFullscreen(next)
    writeAppFullscreen(next)
    void restartScript()
  }

  async function restartScript() {
    try {
      const url = Script.createRunURLScheme("CAIS", { restart: String(Date.now()) })
      const ok = await Safari.openURL(url)
      if (ok === false) {
        showToast("已保存显示模式，下次运行生效")
        return
      }
      Script.exit()
    } catch {
      showToast("已保存显示模式，下次运行生效")
    }
  }

  async function activatePipFromApp() {
    pipPresented.setValue(true)
    startPipMonitor()
    if (Script.supportsMinimization?.()) {
      ;(globalThis as any).setTimeout?.(() => {
        void (async () => {
          intentionalMinimize = true
          try {
            const ok = await Script.minimize()
            if (!ok) intentionalMinimize = false
          } catch {
            intentionalMinimize = false
          }
        })()
      }, 900)
    }
  }

  function renderClipRow(item: ClipItem, options: { allowDelete: boolean } = { allowDelete: true }) {
    const trailingActions = [
      <Button
        title=""
        systemImage={item.kind === "image" ? "photo" : "square.and.pencil"}
        tint={item.kind === "image" ? "systemBlue" : "systemOrange"}
        action={withHaptic(() => {
          if (item.kind === "image") {
            void viewImageItem(item)
          } else {
            void editItem(item)
          }
        })}
      />,
      ...(options.allowDelete ? [
        <Button
          title=""
          systemImage="trash"
          tint="systemRed"
          action={withHaptic(() => requestDeleteItem(item))}
        />,
      ] : []),
    ]

    return (
      <HStack
        key={item.id}
        frame={{ maxWidth: "infinity", alignment: "leading" as any }}
        background="rgba(0,0,0,0.001)"
        contentShape={{
          kind: "contextMenuPreview",
          shape: { type: "rect", cornerRadius: 18 },
        } as any}
        onTapGesture={withHaptic(() => copyItem(item))}
        contextMenu={{
          menuItems: (
            <Group>
              <ControlGroup controlSize="large">
                <Button title="增加标题" systemImage="textformat" action={() => void editItemTitle(item)} />
                {item.kind === "image" ? (
                  <Button title="查看" systemImage="photo" action={() => void viewImageItem(item)} />
                ) : (
                  <Button title="编辑" systemImage="square.and.pencil" action={() => void editItem(item)} />
                )}
                <Button title="分享" systemImage="square.and.arrow.up" action={() => void shareItem(item)} />
              </ControlGroup>
              <Divider />
              {item.kind === "image" ? (
                <Button title="提取文字" systemImage="text.viewfinder" action={() => void extractTextFromImage(item)} />
              ) : null}
              {item.kind !== "image" && settings.keyboardMenu.builtins.tokenize ? (
                <Button title="分词" systemImage="text.magnifyingglass" action={() => void openTokenResultForItem(item)} />
              ) : null}
              {getOrderedMenuBuiltins(settings).map((action) => {
                const enabled = settings.keyboardMenu.builtins[action]
                const supported = action !== "tokenize" && (
                  action === "base64Encode" ||
                  (action === "openUrl" ? item.kind === "url" : item.kind !== "image")
                )
                return enabled && supported ? (
                  <Button
                    key={action}
                    title={menuBuiltinTitle(action)}
                    systemImage={menuBuiltinSystemImage(action)}
                    action={() => void runBuiltinActionForItem(item, action)}
                  />
                ) : null
              })}
              {item.kind !== "image" ? (
                settings.keyboardMenu.customActions
                  .filter((action) => action.enabled)
                  .map((action) => (
                    <Button
                      key={action.id}
                      title={action.title}
                      systemImage={customActionSystemImage(action)}
                      action={() => void runCustomActionForItem(item, action)}
                    />
                  ))
              ) : null}
            </Group>
          ),
        }}
        leadingSwipeActions={{
          allowsFullSwipe: false,
          actions: [
            ...(item.manualFavorite ? [] : [
              <Button
                title=""
                systemImage={item.favorite ? "star.slash" : "star"}
                tint="systemYellow"
                action={() => void toggleFavorite(item).then(() => refresh())}
              />,
            ]),
            <Button
              title=""
              systemImage={item.pinned ? "pin.slash" : "pin"}
              tint="systemOrange"
              action={() => void togglePinned(item).then(() => refresh())}
            />,
          ],
        }}
        trailingSwipeActions={{
          allowsFullSwipe: false,
          actions: trailingActions,
        }}
        confirmationDialog={pendingDeleteItem?.id === item.id && pendingDeleteTab === activeTab.value ? {
          title: "是否删除？",
          isPresented: deleteDialogPresented,
          actions: (
            <Group>
              <Button title="删除" systemImage="trash" role="destructive" action={() => void confirmDeleteItem()} />
              <Button title="取消" role="cancel" action={dismissDeleteDialog} />
            </Group>
          ),
        } : undefined}
        listRowInsets={{ top: 5, bottom: 5, leading: 12, trailing: 12 }}
        listRowBackground={<EmptyView />}
        listRowSeparator={{ visibility: "hidden", edges: "all" as any }}
        listRowSeparatorTint={{ color: "clear", edges: "all" as any }}
      >
        {settings.appClipRowGlassEffect ? (
          <ClipRow
            item={item}
            contentLineLimit={settings.appContentLineLimit}
          />
        ) : (
          <NonGlassClipRow
            item={item}
            contentLineLimit={settings.appContentLineLimit}
          />
        )}
      </HStack>
    )
  }

  function renderGroupedClipList(groups: ClipGroup[], emptyMessage: string, options: { allowDelete?: (item: ClipItem) => boolean } = {}) {
    if (!groups.some((group) => group.items.length)) {
      return (
        <Section
          listSectionSeparator={{ visibility: "hidden", edges: "all" as any }}
          listSectionSeparatorTint={{ color: "clear", edges: "all" as any }}
        >
          <EmptyState title="暂无内容" message={emptyMessage} systemImage="doc.on.clipboard" />
        </Section>
      )
    }
    return (
      <Group>
        {groups.filter((group) => group.items.length)
          .map((group) => (
            <Section
              key={group.title}
              header={<Text>{group.title}</Text>}
              listSectionSeparator={{ visibility: "hidden", edges: "all" as any }}
              listSectionSeparatorTint={{ color: "clear", edges: "all" as any }}
            >
              {group.items.map((item) => renderClipRow(item, { allowDelete: options.allowDelete?.(item) ?? true }))}
            </Section>
          ))}
      </Group>
    )
  }

  function toolbarLeading() {
    if (homeScreenMode) return undefined
    return (
      <HStack spacing={10}>
        <Button
          title=""
          systemImage="xmark.circle.fill"
          foregroundStyle="systemRed"
          action={withHaptic(() => Script.exit())}
        />
        {Script.supportsMinimization?.() ? (
          <Button
            title=""
            systemImage="minus.circle.fill"
            foregroundStyle="systemYellow"
            action={withHaptic(minimizeScript)}
          />
        ) : null}
        <Button
          title=""
          systemImage={appFullscreen ? "arrow.down.right.and.arrow.up.left.circle.fill" : "arrow.up.left.and.arrow.down.right.circle.fill"}
          foregroundStyle="systemBlue"
          action={withHaptic(toggleFullscreenMode)}
        />
      </HStack>
    )
  }

  function pagePicker() {
    return (
      <Picker
        title="页面"
        pickerStyle="segmented"
        value={activeTab.value}
        onChanged={(value: number) => activeTab.setValue(value)}
        frame={{ width: 220 }}
      >
        <Image tag={TAB_FAVORITES} systemName="star" />
        <Image tag={TAB_CLIPS} systemName="doc.on.clipboard" />
        <Image tag={TAB_SETTINGS} systemName="gearshape" />
      </Picker>
    )
  }

  function clipToolbarButtons() {
    return (
      <HStack spacing={10}>
        {pipToolbarButton()}
        <Button
          title=""
          systemImage="doc.badge.plus"
          disabled={loading}
          action={withHaptic(captureNow)}
        />
      </HStack>
    )
  }

  function favoriteToolbarButtons() {
    return (
      <HStack spacing={10}>
        {pipToolbarButton()}
        <Button
          title=""
          systemImage="plus"
          action={withHaptic(async () => {
            const result = await Navigation.present<{ title: string, content: string } | null>({
              element: <AddFavoriteView />,
              modalPresentationStyle: "pageSheet"
            })
            if (result) {
              await addFavoriteFromInput(result.title, result.content)
              showToast("已添加到收藏")
              await refresh()
            }
          })}
        />
      </HStack>
    )
  }

  function pipToolbarButton() {
    return (
      <Button
        title=""
        systemImage={pipPresented.value ? "pip.exit" : "pip.enter"}
        foregroundStyle={pipPresented.value ? "systemBlue" : undefined}
        action={withHaptic(togglePip)}
      />
    )
  }

  function settingsToolbarButtons() {
    return (
      <HStack spacing={10}>
        {pipToolbarButton()}
      </HStack>
    )
  }

  function searchPanel(scope: ClipListScope) {
    const outerPadding = homeScreenMode
      ? { top: 2, bottom: 4, leading: 16, trailing: 16 }
      : { top: 10, bottom: 6, leading: 16, trailing: 16 }
    const counts = clipKindCounts[scope]
    const metrics = [
      { systemName: "list.number", value: counts.total, kind: null },
      { systemName: "doc.text", value: counts.text, kind: "text" },
      { systemName: "link", value: counts.url, kind: "url" },
      { systemName: "photo", value: counts.image, kind: "image" },
    ]
    const filterOptions: Array<{ title: string; systemName: string; kind: ClipKindFilter }> = [
      { title: "所有", systemName: "list.number", kind: null },
      { title: "文本", systemName: "doc.text", kind: "text" },
      { title: "链接", systemName: "link", kind: "url" },
      { title: "图片", systemName: "photo", kind: "image" },
    ]

    function selectKindFilter(kind: ClipKindFilter) {
      if (clipKindFiltersRef.current[scope] === kind) return
      const next = { ...clipKindFiltersRef.current, [scope]: kind }
      clipKindFiltersRef.current = next
      setClipKindFilters(next)
      void refresh(true, settingsRef.current)
    }

    return (
      <VStack
        frame={{ maxWidth: "infinity", alignment: "topLeading" as any }}
        padding={outerPadding}
        listRowInsets={{ top: 0, bottom: 0, leading: 0, trailing: 0 }}
        listRowSeparator="hidden"
        listRowBackground={<EmptyView />}
      >
        <VStack
          frame={{ maxWidth: "infinity", alignment: "leading" as any }}
          padding={{ top: 10, bottom: 10, leading: 14, trailing: 14 }}
          background={{ style: cardFill, shape: { type: "rect", cornerRadius: 18 } }}
          glassEffect={{ type: "rect", cornerRadius: 18 } as any}
        >
          <HStack spacing={8} frame={{ maxWidth: "infinity", alignment: "center" as any }}>
            <Image systemName="magnifyingglass" foregroundStyle="secondaryLabel" frame={{ width: 18 }} />
            <TextField title="" value={query} prompt="输入关键词" onChanged={setQuery} frame={{ maxWidth: "infinity" }} />
            {query.length === 0 ? (
              <Menu
                menuIndicator="hidden"
                label={
                  <HStack spacing={6} fixedSize={{ horizontal: true, vertical: false }}>
                    {metrics.map((metric) => (
                      <HStack
                        key={metric.systemName}
                        spacing={2}
                        foregroundStyle={clipKindFilters[scope] === metric.kind ? "systemBlue" : "secondaryLabel"}
                      >
                        <Image systemName={metric.systemName} font="caption2" />
                        <Text font="caption2" monospacedDigit>{metric.value}</Text>
                      </HStack>
                    ))}
                  </HStack>
                }
              >
                {filterOptions.map((option) => (
                  <Button
                    key={option.title}
                    title={option.title}
                    systemImage={option.systemName}
                    foregroundStyle={clipKindFilters[scope] === option.kind ? "systemBlue" : undefined}
                    action={withHaptic(() => selectKindFilter(option.kind))}
                  />
                ))}
              </Menu>
            ) : null}
          </HStack>
        </VStack>
      </VStack>
    )
  }

  function pipControlPanel() {
    if (!pipPresented.value) return null
    return (
      <VStack
        frame={{ maxWidth: "infinity", alignment: "topLeading" as any }}
        padding={{ top: 10, bottom: 6, leading: 16, trailing: 16 }}
        listRowInsets={{ top: 0, bottom: 0, leading: 0, trailing: 0 }}
        listRowSeparator="hidden"
        listRowBackground={<EmptyView />}
      >
        <VStack
          spacing={8}
          frame={{ maxWidth: "infinity", alignment: "leading" as any }}
          padding={{ top: 10, bottom: 10, leading: 14, trailing: 14 }}
          background={{ style: "systemBackground", shape: { type: "rect", cornerRadius: 18 } }}
          glassEffect={{ type: "rect", cornerRadius: 18 } as any}
        >
          <Text
            font="headline"
            frame={{ maxWidth: "infinity", alignment: "leading" as any }}
            multilineTextAlignment="leading"
          >
            PiP 监听状态
          </Text>
          <Text
            font="caption"
            foregroundStyle="secondaryLabel"
            multilineTextAlignment="leading"
            frame={{ maxWidth: "infinity", alignment: "leading" as any }}
          >
            [{formatDateTime(monitorStatus.lastCheckedAt)}] {monitorStatus.lastMessage} · 已复制 {monitorStatus.capturedCount ?? 0} 条
          </Text>
        </VStack>
      </VStack>
    )
  }

  function rootPresentationProps() {
    return {
      sheet: releaseNotesSheet,
      ...(pipPresented.value ? {
        pip: {
          isPresented: pipPresented,
          maximumUpdatesPerSecond: 2,
          content: (
            <PipStatusView
              status={monitorStatus}
              onStart={startPipMonitor}
              onStop={stopPipMonitor}
            />
          ),
        },
      } : {}),
    }
  }

  function homeToolbarLeading() {
    return (
      <Button
        title={pipPresented.value ? "关闭 PiP" : "开启 PiP"}
        systemImage={pipPresented.value ? "pip.exit" : "pip.enter"}
        foregroundStyle={pipPresented.value ? "systemBlue" : undefined}
        action={withHaptic(togglePip)}
      />
    )
  }

  function homeToolbarTrailing() {
    return (
      <HStack spacing={8}>
        {activeTab.value === TAB_FAVORITES ? (
          <Button
            title="添加常用语"
            systemImage="plus"
            action={withHaptic(async () => {
              const result = await Navigation.present<{ title: string, content: string } | null>({
                element: <AddFavoriteView />,
                modalPresentationStyle: "pageSheet"
              })
              if (result) {
                await addFavoriteFromInput(result.title, result.content)
                showToast("已添加到收藏")
                await refresh()
              }
            })}
          />
        ) : null}
        {activeTab.value !== TAB_FAVORITES ? (
          <Button
            title="采集剪贴板"
            systemImage="doc.badge.plus"
            disabled={loading}
            action={withHaptic(captureNow)}
          />
        ) : null}
      </HStack>
    )
  }

  function homePageToolbar() {
    return {
      topBarLeading: homeToolbarLeading(),
      topBarTrailing: homeToolbarTrailing(),
      principal: pagePicker(),
    }
  }

  function renderHomeCurrentPage() {
    if (activeTab.value === TAB_FAVORITES) {
      return (
        <Form
          formStyle="grouped"
          listRowSpacing={10}
          contentMargins={APP_SCROLL_CONTENT_MARGINS}
          frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
          toast={toastOptions()}
        >
          {searchPanel("favorites")}
          {homeInitialDataReady
            ? renderGroupedClipList(favoriteGroups, query.trim() ? "没有匹配的收藏内容。" : "点击右上角添加常用语，或右滑剪贴板条目点星标。")
            : null}
        </Form>
      )
    }

    if (activeTab.value === TAB_SETTINGS) {
      return (
        <VStack
          frame={{ maxWidth: "infinity", maxHeight: "infinity", alignment: "top" as any }}
          toast={toastOptions()}
        >
          <SettingsView
            value={settings}
            onChanged={updateSettings}
            onClearFavorites={() => void requestClear("favorites")}
            onClearClipboard={(range) => void requestClear(range)}
            lanShareStatus={lanShareStatus}
            onRotateLanShareToken={() => void rotateLanShareToken()}
          />
        </VStack>
      )
    }

    return (
      <Form
        formStyle="grouped"
        listRowSpacing={10}
        contentMargins={APP_SCROLL_CONTENT_MARGINS}
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        toast={toastOptions()}
      >
        {pipControlPanel()}
        {searchPanel("clipboard")}
        {homeInitialDataReady
          ? renderGroupedClipList(
            clipboardGroups,
            query.trim() ? "没有匹配的剪贴板内容。" : "点击右上角采集按钮，或开启 PiP 监听。",
            { allowDelete: (item) => !item.manualFavorite }
          )
          : null}
      </Form>
    )
  }

  if (homeScreenMode) {
    return (
      <VStack
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        navigationBarTitleDisplayMode="inline"
        toolbarTitleDisplayMode="inline"
        toolbar={homePageToolbar()}
        {...rootPresentationProps()}
      >
        {renderHomeCurrentPage()}
      </VStack>
    )
  }

  return (
    <TabView
      selection={activeTab as any}
      tint="systemIndigo"
      tabViewStyle="sidebarAdaptable"
      tabBarMinimizeBehavior="onScrollDown"
      {...rootPresentationProps()}
    >
      <Tab title="收藏" systemImage="star" value={TAB_FAVORITES}>
        <NavigationStack>
          <Form
            formStyle="grouped"
            listRowSpacing={10}
            contentMargins={APP_SCROLL_CONTENT_MARGINS}
            frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
            toolbar={{ topBarLeading: toolbarLeading(), topBarTrailing: favoriteToolbarButtons() }}
            toast={toastOptions()}
          >
            {searchPanel("favorites")}
            {renderGroupedClipList(favoriteGroups, query.trim() ? "没有匹配的收藏内容。" : "点击右上角添加常用语，或右滑剪贴板条目点星标。")}
          </Form>
        </NavigationStack>
      </Tab>

      <Tab title="剪贴板" systemImage="doc.on.clipboard" value={TAB_CLIPS}>
        <NavigationStack>
          <Form
            formStyle="grouped"
            listRowSpacing={10}
            contentMargins={APP_SCROLL_CONTENT_MARGINS}
            frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
            toolbar={{ topBarLeading: toolbarLeading(), topBarTrailing: clipToolbarButtons() }}
            toast={toastOptions()}
          >
            {pipControlPanel()}
            {searchPanel("clipboard")}
            {renderGroupedClipList(
              clipboardGroups,
              query.trim() ? "没有匹配的剪贴板内容。" : "点击右上角采集按钮，或开启 PiP 监听。",
              { allowDelete: (item) => !item.manualFavorite }
            )}
          </Form>
        </NavigationStack>
      </Tab>

      <Tab title="设置" systemImage="gearshape" value={TAB_SETTINGS}>
        <NavigationStack>
          <VStack
            frame={{ maxWidth: "infinity", maxHeight: "infinity", alignment: "top" as any }}
            toast={toastOptions()}
          >
            <SettingsView
              value={settings}
              onChanged={updateSettings}
              onClearFavorites={() => void requestClear("favorites")}
              onClearClipboard={(range) => void requestClear(range)}
              lanShareStatus={lanShareStatus}
              onRotateLanShareToken={() => void rotateLanShareToken()}
              leadingToolbar={toolbarLeading()}
              trailingToolbar={settingsToolbarButtons()}
            />
          </VStack>
        </NavigationStack>
      </Tab>
    </TabView>
  )
}
