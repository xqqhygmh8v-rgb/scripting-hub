import type { CaptureResult, ClipboardClearRange, ClipGroup, ClipItem, ClipKind, ClipKindCountsByScope, ClipListScope, ClipPayload, CaisSettings } from "../types"
import { clipTitle, hashString, isLikelyURL, makeId, normalizeClipContent, normalizeText } from "../utils/common"
import { countClipKindsByScope, countClipsByScope, deleteClipboardClipsByRange, deleteClip, deleteFavoriteClips, findClipByHash, findClipById, findTextClipsByContent, insertClip, listClipGroups, listClips, listImagePaths, trimActiveClips, updateClipContent, updateClipState, updateClipTitle as updateClipTitleRow, getFullClipContent } from "./database"
import { imageContentHash, removeImage, saveImageForClip } from "./image_store"
import { bumpClipDataVersion } from "./change_signal"

function payloadContent(payload: ClipPayload): string {
  if (payload.kind === "image") return `image:${payload.sourceChangeCount ?? Date.now()}`
  if (payload.kind === "url") return normalizeClipContent(payload.url ?? payload.text ?? "")
  return normalizeClipContent(payload.text ?? "")
}

function shouldCapture(payload: ClipPayload, settings: CaisSettings): boolean {
  if (payload.kind === "image") return settings.captureImages
  return settings.captureText
}

async function resolveDuplicate(
  existing: ClipItem,
  textMatches: ClipItem[],
  settings: CaisSettings,
): Promise<CaptureResult> {
  let changed = false
  for (const duplicate of textMatches.filter((match) => match.id !== existing.id)) {
    await deleteClip(duplicate.id)
    changed = true
  }
  if (settings.duplicatePolicy === "skip") {
    if (changed) bumpClipDataVersion()
    return { status: "skipped", reason: "重复内容已存在" }
  }
  const updatedAt = Date.now()
  await updateClipState(existing.id, { updatedAt })
  await trimActiveClips(settings.maxItems)
  bumpClipDataVersion()
  return { status: "updated", item: { ...existing, updatedAt } }
}

export async function addClipFromPayload(payload: ClipPayload, settings: CaisSettings): Promise<CaptureResult> {
  const content = payloadContent(payload)
  if (!content.trim()) return { status: "skipped", reason: "剪贴板为空" }
  const kind = payload.kind === "text" && isLikelyURL(content) ? "url" : payload.kind
  if (!shouldCapture({ ...payload, kind }, settings)) {
    return { status: "skipped", reason: "当前类型未开启采集" }
  }
  let imageHash: string | undefined
  let image: UIImage | undefined
  if (kind === "image") {
    image = payload.image
    if (!image) return { status: "skipped", reason: "图片内容不可读取" }
    imageHash = payload.imageContentHash || imageContentHash(image)
    if (!imageHash) return { status: "skipped", reason: "图片内容不可读取" }
  }
  const contentHash = kind === "image"
    ? hashString(`${kind}:${imageHash}`)
    : hashString(`text:${content}`)
  const textMatches = kind === "image" ? [] : await findTextClipsByContent(content)
  const existing = kind === "image"
    ? await findClipByHash(contentHash, kind)
    : textMatches[0] ?? null
  if (existing) {
    return resolveDuplicate(existing, textMatches, settings)
  }

  const now = Date.now()
  const id = makeId()
  let imagePath: string | undefined
  if (kind === "image") {
    if (!image) return { status: "skipped", reason: "图片内容不可读取" }
    imagePath = await saveImageForClip(id, image)
    if (!imagePath) return { status: "skipped", reason: "图片保存失败" }
  }
  const item: ClipItem = {
    id,
    kind,
    title: clipTitle(kind, content),
    content,
    contentHash,
    imagePath,
    sourceChangeCount: payload.sourceChangeCount,
    createdAt: now,
    updatedAt: now,
    pinned: false,
    favorite: false,
    manualFavorite: false,
    deletedAt: null,
  }
  try {
    await insertClip(item)
  } catch (error) {
    const concurrentMatches = kind === "image" ? [] : await findTextClipsByContent(content)
    const concurrent = kind === "image"
      ? await findClipByHash(contentHash, kind)
      : concurrentMatches[0] ?? null
    if (!concurrent) throw error
    await removeImage(imagePath)
    return resolveDuplicate(concurrent, concurrentMatches, settings)
  }
  await trimActiveClips(settings.maxItems)
  bumpClipDataVersion()
  return { status: "created", item }
}

export async function getClips(search = "", limit = 120, scope?: ClipListScope): Promise<ClipItem[]> {
  return listClips({ search, limit, scope })
}

export async function getClipGroups(scope: ClipListScope, search = "", limit = 120, offset = 0, kind?: ClipKind): Promise<ClipGroup[]> {
  return listClipGroups({ scope, search, limit, offset, kind })
}

export async function getClipCounts(): Promise<Record<ClipListScope, number>> {
  return countClipsByScope()
}

export async function getClipKindCounts(): Promise<ClipKindCountsByScope> {
  return countClipKindsByScope()
}

export async function getClipById(id: string): Promise<ClipItem | null> {
  return findClipById(id)
}

export async function markCopied(item: ClipItem): Promise<void> {
  const now = Date.now()
  await updateClipState(item.id, { updatedAt: now, lastCopiedAt: now })
  bumpClipDataVersion()
}

export async function togglePinned(item: ClipItem): Promise<void> {
  await updateClipState(item.id, { pinned: !item.pinned, updatedAt: Date.now() })
  bumpClipDataVersion()
}

export async function toggleFavorite(item: ClipItem): Promise<void> {
  await updateClipState(item.id, { favorite: !item.favorite })
  bumpClipDataVersion()
}

export async function softDeleteClip(item: ClipItem): Promise<void> {
  await removeImage(item.imagePath)
  await deleteClip(item.id)
  bumpClipDataVersion()
}

export async function clearFavoriteClips(): Promise<void> {
  const imagePaths = await listImagePaths({ favoritesOnly: true })
  await deleteFavoriteClips()
  for (const path of imagePaths) await removeImage(path)
  bumpClipDataVersion()
}

export async function clearClipboardClipsByRange(range: ClipboardClearRange): Promise<void> {
  const imagePaths = await listImagePaths({ clipboardRange: range })
  await deleteClipboardClipsByRange(range)
  for (const path of imagePaths) await removeImage(path)
  bumpClipDataVersion()
}

export async function editClipContent(item: ClipItem, value: string): Promise<ClipItem> {
  const content = normalizeClipContent(value)
  if (!content.trim()) throw new Error("内容不能为空")
  if (!item.manualFavorite) {
    const duplicate = (await findTextClipsByContent(content)).find((match) => match.id !== item.id)
    if (duplicate) throw new Error("相同内容已存在")
  }
  const kind = item.kind === "image" ? "text" : isLikelyURL(content) ? "url" : "text"
  const next: ClipItem = {
    ...item,
    kind,
    title: clipTitle(kind, content),
    content,
    contentHash: hashString(`text:${content}`),
    updatedAt: Date.now(),
    imagePath: undefined,
  }
  try {
    await updateClipContent(next)
  } catch (error) {
    if (!item.manualFavorite) {
      const duplicate = (await findTextClipsByContent(content)).find((match) => match.id !== item.id)
      if (duplicate) throw new Error("相同内容已存在")
    }
    throw error
  }
  bumpClipDataVersion()
  return next
}

export async function updateClipTitle(item: ClipItem, value: string): Promise<ClipItem> {
  const title = normalizeText(value) || clipTitle(item.kind, item.content)
  await updateClipTitleRow(item.id, title)
  bumpClipDataVersion()
  return { ...item, title }
}

export async function addFavoriteFromInput(title: string, content: string): Promise<ClipItem> {
  const fixedContent = normalizeClipContent(content)
  if (!fixedContent.trim()) throw new Error("内容不能为空")
  const kind = isLikelyURL(fixedContent) ? "url" : "text"
  const now = Date.now()
  const item: ClipItem = {
    id: makeId("phrase"),
    kind,
    title: title.trim() || clipTitle(kind, fixedContent),
    content: fixedContent,
    contentHash: hashString(`manual:${kind}:${fixedContent}`),
    sourceChangeCount: 0,
    createdAt: now,
    updatedAt: now,
    pinned: false,
    favorite: true,
    manualFavorite: true,
    deletedAt: null,
  }
  await insertClip(item)
  bumpClipDataVersion()
  return item
}

export { getFullClipContent }
