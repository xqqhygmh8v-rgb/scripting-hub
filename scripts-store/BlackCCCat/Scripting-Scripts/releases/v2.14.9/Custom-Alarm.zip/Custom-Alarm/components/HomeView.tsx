import {
  Button,
  EmptyView,
  ForEach,
  HStack,
  Image,
  List,
  Navigation,
  NavigationStack,
  ProgressView,
  Rectangle,
  Tab,
  TabView,
  Text,
  Toggle,
  VStack,
  ZStack,
  modifiers,
  type Color,
  type KeywordPoint,
  useEffect,
  useColorScheme,
  useMemo,
  useObservable,
  useState,
} from "scripting"

import type { AlarmDraft, AlarmRecord, AlarmRepeatRule, HolidayCalendarSource } from "../types"
import { AddAlarmView } from "./AddAlarmView"
import { CalendarSettingsView } from "./CalendarSettingsView"
import { useReleaseNotesSheet } from "./ReleaseNotesSheet"
import { SoundSettingsView } from "./SoundSettingsView"
import { StatusView } from "./StatusView"
import { SystemAlarmSettingsView } from "./SystemAlarmSettingsView"
import {
  cancelManagedSystemAlarmIds,
  deleteAlarm,
  disableAlarm,
  displaySubtitle,
  displayTime,
  nextOccurrenceDateLabel,
  reconcileAlarmRecords,
  scheduleAlarm,
} from "../utils/alarm_runtime"
import { buildHolidayDayMap, syncHolidayCalendarSource } from "../utils/holiday_calendar"
import { DEFAULT_SOUND_NAME, loadAvailableSoundNames } from "../utils/alarm_sounds"
import {
  ALARM_CONFIGURATION_VERSION,
  collectRecordSystemAlarmIds,
  DEFAULT_HOLIDAY_SOURCE_ID,
  loadCustomAlarmState,
  mergeManagedSystemAlarmIds,
  saveCustomAlarmState,
} from "../utils/storage"

const STATUS_TAB = 0
const ALARMS_TAB = 1
const CALENDARS_TAB = 2
const ACTION_TAB = 3

type ContentTab = typeof STATUS_TAB | typeof ALARMS_TAB | typeof CALENDARS_TAB
type RootTab = ContentTab | typeof ACTION_TAB
type AdvancedCleanupItem = {
  alarmId: string
  timeLabel: string
  title: string
  summary: string
  detail: string
  sourceLabel: string
}
type AdvancedCleanupSnapshot = {
  items: AdvancedCleanupItem[]
  diagnosticItems: AdvancedCleanupItem[]
}

function isContentTab(value: RootTab): value is ContentTab {
  return value === STATUS_TAB || value === ALARMS_TAB || value === CALENDARS_TAB
}

function mergeStoredRecords(current: AlarmRecord[], stored: AlarmRecord[]): AlarmRecord[] {
  // 优先保留更新时间更晚的那份数据，避免监听器刷新时把刚改完的本地状态覆盖回旧值。
  const storedMap = new Map(stored.map((item) => [item.id, item]))
  const merged = current.map((item) => {
    const storedItem = storedMap.get(item.id)
    if (!storedItem) return item
    return (storedItem.updatedAt ?? 0) > (item.updatedAt ?? 0) ? storedItem : item
  })
  const existingIds = new Set(merged.map((item) => item.id))
  for (const item of stored) {
    if (!existingIds.has(item.id)) merged.push(item)
  }
  return merged
}

function normalizeRepeatRule(rule: AlarmRepeatRule): string {
  switch (rule.kind) {
    case "once":
      return JSON.stringify({
        kind: rule.kind,
        timestamp: rule.timestamp,
      })
    case "daily":
      return JSON.stringify({
        kind: rule.kind,
        hour: rule.hour,
        minute: rule.minute,
        occurrenceLimit: rule.occurrenceLimit ?? null,
      })
    case "weekly":
      return JSON.stringify({
        kind: rule.kind,
        hour: rule.hour,
        minute: rule.minute,
        weekdays: [...rule.weekdays].sort((a, b) => a - b),
        occurrenceLimit: rule.occurrenceLimit ?? null,
      })
    case "monthly":
      return JSON.stringify({
        kind: rule.kind,
        hour: rule.hour,
        minute: rule.minute,
        dayOfMonth: rule.dayOfMonth,
        occurrenceLimit: rule.occurrenceLimit ?? null,
      })
    case "holiday":
      return JSON.stringify({
        kind: rule.kind,
        hour: rule.hour,
        minute: rule.minute,
        sourceId: rule.sourceId,
        matchMode: rule.matchMode,
      })
    case "custom":
      return JSON.stringify({
        kind: rule.kind,
        hour: rule.hour,
        minute: rule.minute,
        startDateTimestamp: rule.startDateTimestamp,
        skipDays: rule.skipDays,
        ringDays: rule.ringDays,
        occurrenceLimit: rule.occurrenceLimit ?? null,
      })
    default:
      return JSON.stringify(rule)
  }
}

function alarmDraftKey(draft: AlarmDraft): string {
  return JSON.stringify({
    title: draft.title.trim(),
    snoozeMinutes: draft.snoozeMinutes,
    soundName: draft.soundName,
    repeatRule: normalizeRepeatRule(draft.repeatRule),
  })
}

function toAlarmDraft(record: AlarmRecord): AlarmDraft {
  return {
    title: record.title,
    snoozeMinutes: record.snoozeMinutes,
    soundName: record.soundName,
    repeatRule: record.repeatRule,
  }
}

function twoDigits(value: number): string {
  return String(value).padStart(2, "0")
}

function systemAlarmTimeLabel(alarm: AlarmManager.Alarm): string {
  const schedule = alarm.schedule
  if (schedule?.type === "fixed" && schedule.date) {
    const date = new Date(schedule.date)
    return `${twoDigits(date.getHours())}:${twoDigits(date.getMinutes())}`
  }
  if (typeof schedule?.hour === "number" && typeof schedule?.minute === "number") {
    return `${twoDigits(schedule.hour)}:${twoDigits(schedule.minute)}`
  }
  return "无固定时间"
}

function describeSystemAlarm(alarm: AlarmManager.Alarm): string {
  const schedule = alarm.schedule
  if (!schedule) return `无时间规则 · ${alarm.state}`

  if (schedule.type === "fixed" && schedule.date) {
    const date = new Date(schedule.date)
    const yyyy = date.getFullYear()
    const mm = twoDigits(date.getMonth() + 1)
    const dd = twoDigits(date.getDate())
    const hh = twoDigits(date.getHours())
    const min = twoDigits(date.getMinutes())
    return `${yyyy}-${mm}-${dd} ${hh}:${min} · ${alarm.state}`
  }

  if (schedule.weekdays?.length) {
    const labels = ["周日", "周一", "周二", "周三", "周四", "周五", "周六"]
    const weekdayText = schedule.weekdays
      .map((weekday) => labels[(weekday - 1 + 7) % 7] ?? String(weekday))
      .join("、")
    return `${weekdayText} ${twoDigits(schedule.hour ?? 0)}:${twoDigits(schedule.minute ?? 0)} · ${alarm.state}`
  }

  if (typeof schedule.hour === "number" && typeof schedule.minute === "number") {
    return `每天 ${twoDigits(schedule.hour)}:${twoDigits(schedule.minute)} · ${alarm.state}`
  }

  return alarm.state
}

function alarmScheduleKindLabel(alarm: AlarmManager.Alarm): string {
  const schedule = alarm.schedule
  if (!schedule) return "未知规则"
  if (schedule.type === "fixed" && schedule.date) return "固定时间"
  if (schedule.weekdays?.length) return "每周重复"
  if (typeof schedule.hour === "number" && typeof schedule.minute === "number") return "每日重复"
  return "未知规则"
}

function rowSwipeActions(props: {
  onEdit: () => void
  onDelete: () => void
}) {
  return {
    allowsFullSwipe: false,
    actions: [
      <Button title="编辑" action={props.onEdit} />,
      <Button title="删除" role="destructive" tint="red" action={props.onDelete} />,
    ],
  }
}

function AlarmMetaTag(props: {
  icon: string
  text: string
  tint?: string
}) {
  const tint = (props.tint ?? "#FF9500") as any
  return (
    <HStack spacing={8} frame={{ maxWidth: "infinity", alignment: "leading" as any }}>
      <Image
        systemName={props.icon}
        foregroundStyle={tint}
        frame={{ width: 12, alignment: "center" as any }}
      />
      <Text
        font="caption2"
        foregroundStyle="secondaryLabel"
        frame={{ maxWidth: "infinity", alignment: "leading" as any }}
      >
        {props.text}
      </Text>
    </HStack>
  )
}

type AlarmCardGradientConfig = {
  lightColors: Color[]
  darkColors: Color[]
  startPoint: KeywordPoint
  endPoint: KeywordPoint
}

const ALARM_CARD_GRADIENT_POINTS = {
  startPoint: "topLeading" as KeywordPoint,
  endPoint: "bottomTrailing" as KeywordPoint,
}

const ALARM_CARD_GRADIENTS: Record<AlarmRepeatRule["kind"], AlarmCardGradientConfig> = {
  once: {
    ...ALARM_CARD_GRADIENT_POINTS,
    lightColors: ["#FFF7ED", "#FED7AA", "#FDBA74"],
    darkColors: ["#21120A", "#5C2D0C", "#9A3412"],
  },
  daily: {
    ...ALARM_CARD_GRADIENT_POINTS,
    lightColors: ["#ECFDF5", "#A7F3D0", "#6EE7B7"],
    darkColors: ["#061C14", "#064E3B", "#047857"],
  },
  weekly: {
    ...ALARM_CARD_GRADIENT_POINTS,
    lightColors: ["#EFF6FF", "#BFDBFE", "#93C5FD"],
    darkColors: ["#071527", "#1E3A8A", "#2563EB"],
  },
  monthly: {
    ...ALARM_CARD_GRADIENT_POINTS,
    lightColors: ["#F5F3FF", "#DDD6FE", "#C4B5FD"],
    darkColors: ["#181226", "#4C1D95", "#7C3AED"],
  },
  holiday: {
    ...ALARM_CARD_GRADIENT_POINTS,
    lightColors: ["#FFF1F2", "#FDA4AF", "#FB7185"],
    darkColors: ["#260B12", "#881337", "#BE123C"],
  },
  custom: {
    ...ALARM_CARD_GRADIENT_POINTS,
    lightColors: ["#ECFEFF", "#A5F3FC", "#67E8F9"],
    darkColors: ["#061C22", "#155E75", "#0891B2"],
  },
}

function AlarmCardGradient(props: {
  kind: AlarmRepeatRule["kind"]
}) {
  const gradientConfig = ALARM_CARD_GRADIENTS[props.kind]

  return (
    <Rectangle
      fill={{
        light: {
          colors: gradientConfig.lightColors,
          startPoint: gradientConfig.startPoint,
          endPoint: gradientConfig.endPoint,
        },
        dark: {
          colors: gradientConfig.darkColors,
          startPoint: gradientConfig.startPoint,
          endPoint: gradientConfig.endPoint,
        },
      }}
      allowsHitTesting={false}
    />
  )
}

function AlarmRow(props: {
  record: AlarmRecord
  subtitle: string
  nextDateText: string
  gradientEnabled: boolean
  onToggle: (record: AlarmRecord, enabled: boolean) => void | Promise<void>
}) {
  const titleText = props.record.title.trim()
  const showsTitle = titleText.length > 0 && titleText !== "闹钟"

  return (
    <ZStack
      alignment="center"
      frame={{ maxWidth: "infinity", alignment: "leading" as any }}
      glassEffect={{ type: "rect", cornerRadius: 22 } as any}
      clipShape={{ type: "rect", cornerRadius: 22 } as any}
      modifiers={
        modifiers()
          .contentShape({
            kind: "interaction",
            shape: {
              type: "rect",
              cornerRadius: 22,
            },
          })
          .contentShape({
            kind: "dragPreview",
            shape: {
              type: "rect",
              cornerRadius: 22,
            },
          })
      }
    >
      {props.gradientEnabled ? <AlarmCardGradient kind={props.record.repeatRule.kind} /> : null}
      <HStack
        spacing={10}
        frame={{ maxWidth: "infinity", alignment: "leading" as any }}
        padding={{ top: 12, bottom: 12, leading: 14, trailing: 10 }}
      >
        <VStack frame={{ maxWidth: "infinity", alignment: "topLeading" as any }} spacing={6}>
          <HStack spacing={10} frame={{ maxWidth: "infinity", alignment: "top" as any }}>
            <VStack frame={{ maxWidth: "infinity", alignment: "topLeading" as any }} spacing={2}>
              <Text
                font="title2"
                foregroundStyle={props.record.enabled ? "label" : "secondaryLabel"}
                frame={{ maxWidth: "infinity", alignment: "leading" as any }}
              >
                {displayTime(props.record)}
              </Text>
              {showsTitle ? (
                <Text
                  font="subheadline"
                  foregroundStyle={props.record.enabled ? "label" : "secondaryLabel"}
                  frame={{ maxWidth: "infinity", alignment: "leading" as any }}
                >
                  {titleText}
                </Text>
              ) : null}
            </VStack>
            <VStack frame={{ width: 56, alignment: "trailing" as any }}>
              <Toggle
                title=""
                value={props.record.enabled}
                onChanged={(value: boolean) => props.onToggle(props.record, value)}
                toggleStyle="switch"
              />
            </VStack>
          </HStack>
          <VStack spacing={4} frame={{ maxWidth: "infinity", alignment: "leading" as any }}>
            <AlarmMetaTag
              icon="arrow.trianglehead.2.clockwise"
              text={props.subtitle}
            />
            <AlarmMetaTag
              icon="calendar"
              text={`下次 ${props.nextDateText}`}
              tint="#2563EB"
            />
          </VStack>
        </VStack>
      </HStack>
    </ZStack>
  )
}

export function HomeView() {
  const colorScheme = useColorScheme()
  const releaseNotesSheet = useReleaseNotesSheet({
    title: "更新说明",
    // Legacy identifier retained so renaming the Markdown file does not reset read state.
    storageKey: "custom-alarm:release-notes:release-notes.md:last-seen-hash",
  })
  const [initialState] = useState(() => loadCustomAlarmState())
  const [records, setRecords] = useState<AlarmRecord[]>(() => initialState.alarms)
  const [holidaySources, setHolidaySources] = useState<HolidayCalendarSource[]>(() => initialState.holidaySources)
  const [availableSounds, setAvailableSounds] = useState<string[]>(() => initialState.availableSounds)
  const [alarmCardGradientEnabled, setAlarmCardGradientEnabled] = useState<boolean>(() => initialState.alarmCardGradientEnabled)
  const [managedSystemAlarmIds, setManagedSystemAlarmIds] = useState<string[]>(() => initialState.managedSystemAlarmIds)
  const [cleanupCandidateAlarmIds, setCleanupCandidateAlarmIds] = useState<string[]>(() => initialState.cleanupCandidateAlarmIds)
  const [alarmConfigurationVersion, setAlarmConfigurationVersion] = useState<number>(() => initialState.alarmConfigurationVersion)
  const [systemAlarms, setSystemAlarms] = useState<AlarmManager.Alarm[]>([])
  const [globalBusy, setGlobalBusy] = useState(false)
  const [busyRecordId, setBusyRecordId] = useState<string | null>(null)
  const [calendarRefreshing, setCalendarRefreshing] = useState(false)
  const [alarmWriting, setAlarmWriting] = useState(false)
  const [alarmDeleting, setAlarmDeleting] = useState(false)
  const activeTab = useObservable<RootTab>(ALARMS_TAB)
  const [lastContentTab, setLastContentTab] = useState<ContentTab>(ALARMS_TAB)
  const [actionRunning, setActionRunning] = useState(false)

  const holidaySourceMap = useMemo(() => {
    return new Map(holidaySources.map((item) => [item.id, item]))
  }, [holidaySources])
  const systemAlarmIdSet = useMemo(() => {
    return new Set(systemAlarms.map((item) => item.id))
  }, [systemAlarms])

  const enabledCount = useMemo(() => records.filter((item) => item.enabled).length, [records])
  const managedInstanceCount = useMemo(() => {
    const activeIds = new Set<string>()
    for (const record of records) {
      for (const id of record.systemAlarmIds) {
        if (systemAlarmIdSet.has(id)) activeIds.add(id)
      }
    }
    return activeIds.size
  }, [records, systemAlarmIdSet])
  const selectedHolidaySource = holidaySources.find((item) => item.id === DEFAULT_HOLIDAY_SOURCE_ID) ?? holidaySources[0] ?? null
  const currentMonthSummary = useMemo(() => {
    if (!selectedHolidaySource) return { totalOff: 0, remainingOff: 0, totalWork: 0, remainingWork: 0 }

    const dayMap = buildHolidayDayMap(selectedHolidaySource)
    const now = new Date()
    const prefix = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-`
    const todayKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`
    let totalOff = 0
    let remainingOff = 0
    let totalWork = 0
    let remainingWork = 0

    for (const [dateKey, info] of dayMap.entries()) {
      if (!dateKey.startsWith(prefix)) continue
      if (info.kind === "off") {
        totalOff += 1
        if (dateKey >= todayKey) remainingOff += 1
      }
      if (info.kind === "work") {
        totalWork += 1
        if (dateKey >= todayKey) remainingWork += 1
      }
    }

    return { totalOff, remainingOff, totalWork, remainingWork }
  }, [selectedHolidaySource])

  function saveStateSnapshot(
    nextRecords: AlarmRecord[],
    nextHolidaySources = holidaySources,
    nextAvailableSounds = availableSounds,
    nextManagedSystemAlarmIds = managedSystemAlarmIds,
    nextCleanupCandidateAlarmIds = cleanupCandidateAlarmIds,
    nextAlarmConfigurationVersion = alarmConfigurationVersion
  ) {
    saveCustomAlarmState({
      alarms: nextRecords,
      holidaySources: nextHolidaySources,
      availableSounds: nextAvailableSounds,
      alarmCardGradientEnabled,
      managedSystemAlarmIds: nextManagedSystemAlarmIds,
      cleanupCandidateAlarmIds: nextCleanupCandidateAlarmIds,
      alarmConfigurationVersion: nextAlarmConfigurationVersion,
    })
  }

  function markCleanupCandidates(ids: string[]): string[] {
    if (!ids.length) return cleanupCandidateAlarmIds
    const next = mergeManagedSystemAlarmIds(cleanupCandidateAlarmIds, ids)
    setCleanupCandidateAlarmIds(next)
    saveStateSnapshot(records, holidaySources, availableSounds, managedSystemAlarmIds, next)
    return next
  }

  async function migrateAlarmConfigurationsIfNeeded() {
    const storedState = loadCustomAlarmState()
    if (storedState.alarmConfigurationVersion >= ALARM_CONFIGURATION_VERSION) return
    if (!AlarmManager.isAvailable) return

    const sourceMap = new Map(storedState.holidaySources.map((item) => [item.id, item]))
    const migratedRecords: AlarmRecord[] = []
    let migrationFailed = false

    for (const record of storedState.alarms) {
      if (!record.enabled || !record.systemAlarmIds.length) {
        migratedRecords.push(record)
        continue
      }

      try {
        migratedRecords.push(await scheduleAlarm(record, sourceMap))
      } catch {
        migrationFailed = true
        migratedRecords.push(record)
      }
    }

    const nextManagedIds = collectRecordSystemAlarmIds(migratedRecords)
    const nextAlarmConfigurationVersion = migrationFailed
      ? storedState.alarmConfigurationVersion
      : ALARM_CONFIGURATION_VERSION
    setRecords(migratedRecords)
    setManagedSystemAlarmIds(nextManagedIds)
    setAlarmConfigurationVersion(nextAlarmConfigurationVersion)
    saveStateSnapshot(
      migratedRecords,
      storedState.holidaySources,
      storedState.availableSounds,
      nextManagedIds,
      storedState.cleanupCandidateAlarmIds,
      nextAlarmConfigurationVersion
    )
    await refreshSystemState()
  }

  function buildAdvancedCleanupItems(
    nextSystemAlarms = systemAlarms,
    nextRecords = records,
    nextCleanupCandidateIds = cleanupCandidateAlarmIds
  ): AdvancedCleanupItem[] {
    const cleanupCandidateSet = new Set(nextCleanupCandidateIds)

    return [...nextSystemAlarms]
      .sort((a, b) => systemAlarmTimeLabel(a).localeCompare(systemAlarmTimeLabel(b)))
      .filter((alarm) => cleanupCandidateSet.has(alarm.id))
      .map((alarm): AdvancedCleanupItem | null => {
        const owner = nextRecords.find((record) => record.systemAlarmIds.includes(alarm.id))
        if (owner) return null
        return {
          alarmId: alarm.id,
          timeLabel: systemAlarmTimeLabel(alarm),
          title: "首页已删除的残留闹钟",
          summary: "首页已经删除，但系统里仍然残留的闹钟实例。",
          detail: describeSystemAlarm(alarm),
          sourceLabel: "来源：删除后残留，允许在这里手动清理",
        }
      })
      .filter((item: AdvancedCleanupItem | null): item is AdvancedCleanupItem => Boolean(item))
  }

  function buildDiagnosticItems(
    nextSystemAlarms = systemAlarms,
    nextRecords = records,
    nextManagedIds = managedSystemAlarmIds,
    nextCleanupCandidateIds = cleanupCandidateAlarmIds
  ): AdvancedCleanupItem[] {
    const managedIdSet = new Set(nextManagedIds)
    const cleanupIdSet = new Set(nextCleanupCandidateIds)

    return [...nextSystemAlarms]
      .sort((a, b) => systemAlarmTimeLabel(a).localeCompare(systemAlarmTimeLabel(b)))
      .map((alarm): AdvancedCleanupItem => {
        const owner = nextRecords.find((record) => record.systemAlarmIds.includes(alarm.id))
        const linkedLabel = owner ? displaySubtitle(owner, holidaySourceMap) : "未关联到当前首页闹钟"
        const sourceParts = [
          owner ? "当前首页闹钟已关联" : "当前首页闹钟未关联",
          managedIdSet.has(alarm.id) ? "脚本已登记" : "脚本未登记",
          cleanupIdSet.has(alarm.id) ? "已标记为残留候选" : null,
        ].filter(Boolean)

        return {
          alarmId: alarm.id,
          timeLabel: systemAlarmTimeLabel(alarm),
          title: owner?.title || "未关联到当前首页闹钟",
          summary: `${alarmScheduleKindLabel(alarm)} · ${linkedLabel}`,
          detail: describeSystemAlarm(alarm),
          sourceLabel: sourceParts.join(" · "),
        }
      })
  }

  useEffect(() => {
    saveCustomAlarmState({
      alarms: records,
      holidaySources,
      availableSounds,
      alarmCardGradientEnabled,
      managedSystemAlarmIds,
      cleanupCandidateAlarmIds,
      alarmConfigurationVersion,
    })
  }, [records, holidaySources, availableSounds, alarmCardGradientEnabled, managedSystemAlarmIds, cleanupCandidateAlarmIds, alarmConfigurationVersion])

  useEffect(() => {
    if (!AlarmManager.isAvailable) return

    const listener = () => {
      void refreshSystemState()
    }

    AlarmManager.addAlarmUpdateListener(listener)
    void (async () => {
      await refreshSystemState()
      await migrateAlarmConfigurationsIfNeeded()
    })()
    void refreshAvailableSounds({ showError: false })

    return () => {
      AlarmManager.removeAlarmUpdateListener(listener)
    }
  }, [])

  useEffect(() => {
    const today = new Date()
    const isJanFirst = today.getMonth() === 0 && today.getDate() === 1
    if (!isJanFirst) return

    const source = holidaySources.find((item) => item.id === DEFAULT_HOLIDAY_SOURCE_ID) ?? holidaySources[0] ?? null
    if (!source) return

    const lastSyncedAt = source.lastSyncedAt ? new Date(source.lastSyncedAt) : null
    const alreadySyncedToday = Boolean(
      lastSyncedAt
      && lastSyncedAt.getFullYear() === today.getFullYear()
      && lastSyncedAt.getMonth() === today.getMonth()
      && lastSyncedAt.getDate() === today.getDate()
    )

    if (!alreadySyncedToday) {
      void refreshBuiltinHolidayCalendar({ showLoading: false })
    }
  }, [holidaySources])

  useEffect(() => {
    if (isContentTab(activeTab.value)) {
      setLastContentTab(activeTab.value)
      return
    }

    if (actionRunning) return
    setActionRunning(true)

    void (async () => {
      try {
        if (lastContentTab === STATUS_TAB) {
          await refreshStatusPanel()
        } else if (lastContentTab === ALARMS_TAB) {
          await addAlarm()
        } else {
          if (!calendarRefreshing) await refreshBuiltinHolidayCalendar({ showLoading: true })
        }
      } finally {
        activeTab.setValue(lastContentTab)
        setActionRunning(false)
      }
    })()
  }, [activeTab.value, lastContentTab, actionRunning, calendarRefreshing])

  async function refreshSystemState(): Promise<AdvancedCleanupSnapshot | void> {
    if (!AlarmManager.isAvailable) {
      setSystemAlarms([])
      return {
        items: [],
        diagnosticItems: [],
      }
    }
    try {
      const storedState = loadCustomAlarmState()
      const alarms = await AlarmManager.alarms()
      setSystemAlarms(alarms)
      const alarmMap = new Map(alarms.map((item) => [item.id, item]))
      let nextRecordsSnapshot: AlarmRecord[] = []
      setRecords((current) => {
        nextRecordsSnapshot = reconcileAlarmRecords(mergeStoredRecords(current, storedState.alarms), alarmMap)
        return nextRecordsSnapshot
      })
      const referencedIds = collectRecordSystemAlarmIds(nextRecordsSnapshot)
      const nextManagedIds = mergeManagedSystemAlarmIds(storedState.managedSystemAlarmIds, referencedIds)
      const orphanIds = nextManagedIds.filter((id) => !referencedIds.includes(id))
      const cleanupCandidateSet = new Set([
        ...storedState.cleanupCandidateAlarmIds,
        ...orphanIds,
      ])
      if (orphanIds.length) {
        await cancelManagedSystemAlarmIds(orphanIds)
      }
      const referencedIdSet = new Set(referencedIds)
      const nextCleanupCandidateIds = alarms
        .map((item) => item.id)
        .filter((id) => cleanupCandidateSet.has(id) && !referencedIdSet.has(id))
      setManagedSystemAlarmIds(referencedIds)
      setCleanupCandidateAlarmIds(nextCleanupCandidateIds)
      saveStateSnapshot(nextRecordsSnapshot, holidaySources, availableSounds, referencedIds, nextCleanupCandidateIds)
      return {
        items: buildAdvancedCleanupItems(alarms, nextRecordsSnapshot, nextCleanupCandidateIds),
        diagnosticItems: buildDiagnosticItems(alarms, nextRecordsSnapshot, referencedIds, nextCleanupCandidateIds),
      }
    } catch {
      return {
        items: buildAdvancedCleanupItems(systemAlarms, records, cleanupCandidateAlarmIds),
        diagnosticItems: buildDiagnosticItems(systemAlarms, records, managedSystemAlarmIds, cleanupCandidateAlarmIds),
      }
    }
  }

  async function openSystemAlarmSettings() {
    await Navigation.present({
      element: (
        <SystemAlarmSettingsView
          items={buildAdvancedCleanupItems()}
          diagnosticItems={buildDiagnosticItems()}
          onRefresh={refreshSystemState}
          onDeleteIds={deleteSystemAlarmIds}
        />
      ),
    })
  }

  async function upsertRecord(nextRecord: AlarmRecord) {
    setRecords((current) => {
      const exists = current.find((item) => item.id === nextRecord.id)
      const next = exists
        ? current.map((item) => (item.id === nextRecord.id ? nextRecord : item))
        : [...current, nextRecord]
      const nextManagedIds = mergeManagedSystemAlarmIds(managedSystemAlarmIds, collectRecordSystemAlarmIds(next))
      setManagedSystemAlarmIds(nextManagedIds)
      saveStateSnapshot(next, holidaySources, availableSounds, nextManagedIds, cleanupCandidateAlarmIds)
      return next
    })
  }

  function moveRecords(indices: number[], newOffset: number) {
    setRecords((current) => {
      const movingItems = indices.map((index) => current[index]).filter(Boolean)
      const next = current.filter((_, index) => !indices.includes(index))
      next.splice(newOffset, 0, ...movingItems)
      saveStateSnapshot(next, holidaySources, availableSounds, managedSystemAlarmIds, cleanupCandidateAlarmIds)
      return next
    })
  }

  async function addAlarm() {
    if (globalBusy) return
    const nextSounds = await refreshAvailableSounds({ showError: false })
    const draft = await Navigation.present<AlarmDraft>({
      element: (
        <AddAlarmView
          holidaySources={holidaySources}
          availableSounds={nextSounds}
          existingDrafts={records.map(toAlarmDraft)}
          mode="create"
        />
      ),
    })
    if (!draft) return

    if (records.some((item) => alarmDraftKey({
      title: item.title,
      snoozeMinutes: item.snoozeMinutes,
      soundName: item.soundName,
      repeatRule: item.repeatRule,
    }) === alarmDraftKey(draft))) {
      await Dialog.alert({ message: "闹钟已存在。" })
      return
    }

    if (!AlarmManager.isAvailable) {
      await Dialog.alert({ message: "当前系统不支持 AlarmManager。" })
      return
    }

    setGlobalBusy(true)
    setAlarmWriting(true)
    try {
      const baseRecord: AlarmRecord = {
        id: UUID.string(),
        title: draft.title,
        enabled: true,
        snoozeMinutes: draft.snoozeMinutes,
        soundName: draft.soundName,
        repeatRule: draft.repeatRule,
        completedOccurrences: 0,
        systemAlarmIds: [],
        lastScheduledAt: null,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      }
      const scheduled = await scheduleAlarm(baseRecord, holidaySourceMap)
      await upsertRecord(scheduled)
      await refreshSystemState()
    } catch (error: any) {
      await Dialog.alert({ message: String(error?.message ?? error) })
    } finally {
      setAlarmWriting(false)
      setGlobalBusy(false)
    }
  }

  async function applyHolidaySources(updatedSources: HolidayCalendarSource[], options?: { muteBusy?: boolean }) {
    // 节假日日历更新后，只重新排期受影响的节假日闹钟，避免把其他规则的闹钟也重排一遍。
    setHolidaySources(updatedSources)

    const holidaySourceMapAfterUpdate = new Map(updatedSources.map((item) => [item.id, item]))
    const affectedRecords = records.filter((item) => item.enabled && item.repeatRule.kind === "holiday")

    if (!affectedRecords.length || !AlarmManager.isAvailable) return

    const replacingIds = collectRecordSystemAlarmIds(affectedRecords)
    const nextCleanupCandidateIds = replacingIds.length
      ? markCleanupCandidates(replacingIds)
      : cleanupCandidateAlarmIds

    if (!options?.muteBusy) setGlobalBusy(true)
    try {
      const systemAlarmMap = new Map(systemAlarms.map((item) => [item.id, item]))
      const updatedRecords: AlarmRecord[] = []
      for (const record of records) {
        if (record.repeatRule.kind !== "holiday" || !record.enabled) {
          updatedRecords.push(record)
          continue
        }
        if (!holidaySourceMapAfterUpdate.has(record.repeatRule.sourceId)) {
          updatedRecords.push(await disableAlarm(record, systemAlarmMap))
          continue
        }
        updatedRecords.push(await scheduleAlarm(record, holidaySourceMapAfterUpdate))
      }
      setRecords(updatedRecords)
      const nextManagedIds = mergeManagedSystemAlarmIds(managedSystemAlarmIds, collectRecordSystemAlarmIds(updatedRecords))
      setManagedSystemAlarmIds(nextManagedIds)
      saveStateSnapshot(updatedRecords, updatedSources, availableSounds, nextManagedIds, nextCleanupCandidateIds)
      await refreshSystemState()
    } catch (error: any) {
      await Dialog.alert({ message: String(error?.message ?? error) })
    } finally {
      if (!options?.muteBusy) setGlobalBusy(false)
    }
  }

  async function editAlarm(record: AlarmRecord) {
    if (globalBusy || busyRecordId) return
    const nextSounds = await refreshAvailableSounds({ showError: false })
    const draft = await Navigation.present<AlarmDraft>({
      element: (
        <AddAlarmView
          holidaySources={holidaySources}
          availableSounds={nextSounds}
          existingDrafts={records.filter((item) => item.id !== record.id).map(toAlarmDraft)}
          mode="edit"
          initial={{
            title: record.title,
            snoozeMinutes: record.snoozeMinutes,
            soundName: record.soundName,
            repeatRule: record.repeatRule,
          }}
        />
      ),
    })
    if (!draft || !AlarmManager.isAvailable) return

    if (records.some((item) => {
      if (item.id === record.id) return false
      return alarmDraftKey({
        title: item.title,
        snoozeMinutes: item.snoozeMinutes,
        soundName: item.soundName,
        repeatRule: item.repeatRule,
      }) === alarmDraftKey(draft)
    })) {
      await Dialog.alert({ message: "闹钟已存在。" })
      return
    }

    setGlobalBusy(true)
    try {
      const nextCleanupCandidateIds = record.systemAlarmIds.length
        ? markCleanupCandidates(record.systemAlarmIds)
        : cleanupCandidateAlarmIds
      const optimisticRecord: AlarmRecord = {
        ...record,
        title: draft.title,
        snoozeMinutes: draft.snoozeMinutes,
        soundName: draft.soundName,
        repeatRule: draft.repeatRule,
        completedOccurrences: normalizeRepeatRule(record.repeatRule) === normalizeRepeatRule(draft.repeatRule)
          ? (record.completedOccurrences ?? 0)
          : 0,
        enabled: record.enabled,
        updatedAt: Date.now(),
      }
      const optimisticRecords = records.map((item) => (item.id === record.id ? optimisticRecord : item))
      setRecords(optimisticRecords)
      saveStateSnapshot(optimisticRecords, holidaySources, availableSounds, managedSystemAlarmIds, nextCleanupCandidateIds)

      const nextRecord = await scheduleAlarm(optimisticRecord, holidaySourceMap)
      const nextRecords = optimisticRecords.map((item) => (item.id === record.id ? nextRecord : item))
      setRecords(nextRecords)
      const nextManagedIds = mergeManagedSystemAlarmIds(managedSystemAlarmIds, collectRecordSystemAlarmIds(nextRecords))
      setManagedSystemAlarmIds(nextManagedIds)
      saveStateSnapshot(nextRecords, holidaySources, availableSounds, nextManagedIds, nextCleanupCandidateIds)
      await refreshSystemState()
    } catch (error: any) {
      const rollbackRecords = records.map((item) => (item.id === record.id ? record : item))
      setRecords(rollbackRecords)
      saveStateSnapshot(rollbackRecords, holidaySources, availableSounds, managedSystemAlarmIds, cleanupCandidateAlarmIds)
      await Dialog.alert({ message: String(error?.message ?? error) })
    } finally {
      setGlobalBusy(false)
    }
  }

  async function toggleAlarm(record: AlarmRecord, enabled: boolean) {
    if (!AlarmManager.isAvailable) {
      await Dialog.alert({ message: "当前系统不支持 AlarmManager。" })
      return
    }
    if (busyRecordId === record.id) return

    setBusyRecordId(record.id)
    try {
      const nextCleanupCandidateIds = !enabled && record.systemAlarmIds.length
        ? markCleanupCandidates(record.systemAlarmIds)
        : cleanupCandidateAlarmIds
      const systemAlarmMap = new Map(systemAlarms.map((item) => [item.id, item]))
      const optimisticRecord: AlarmRecord = {
        ...record,
        enabled,
        updatedAt: Date.now(),
      }
      const optimisticRecords = records.map((item) => (item.id === record.id ? optimisticRecord : item))
      setRecords(optimisticRecords)
      saveStateSnapshot(optimisticRecords, holidaySources, availableSounds, managedSystemAlarmIds, nextCleanupCandidateIds)

      const nextRecord = enabled
        ? await scheduleAlarm(optimisticRecord, holidaySourceMap)
        : await disableAlarm(record, systemAlarmMap)
      const nextRecords = optimisticRecords.map((item) => (item.id === record.id ? nextRecord : item))
      setRecords(nextRecords)
      const nextManagedIds = mergeManagedSystemAlarmIds(managedSystemAlarmIds, collectRecordSystemAlarmIds(nextRecords))
      setManagedSystemAlarmIds(nextManagedIds)
      saveStateSnapshot(nextRecords, holidaySources, availableSounds, nextManagedIds, nextCleanupCandidateIds)
      void refreshSystemState()
    } catch (error: any) {
      const rollbackRecords = records.map((item) => (item.id === record.id ? record : item))
      setRecords(rollbackRecords)
      saveStateSnapshot(rollbackRecords, holidaySources, availableSounds, managedSystemAlarmIds, cleanupCandidateAlarmIds)
      await Dialog.alert({ message: String(error?.message ?? error) })
    } finally {
      setBusyRecordId(null)
    }
  }

  function updateAlarmCardGradientEnabled(enabled: boolean) {
    if (enabled === alarmCardGradientEnabled) return
    setAlarmCardGradientEnabled(enabled)
  }

  function renderStatusTab() {
    return (
      <NavigationStack>
        <StatusView
          embedded
          logicalAlarmCount={records.length}
          enabledCount={enabledCount}
          managedInstanceCount={managedInstanceCount}
          cleanupCandidateCount={cleanupCandidateAlarmIds.length}
          currentHolidayTitle={selectedHolidaySource?.title || ""}
          syncedHolidayCount={selectedHolidaySource?.holidayDates.length ?? 0}
          currentMonthTotalOffCount={currentMonthSummary.totalOff}
          currentMonthRemainingOffCount={currentMonthSummary.remainingOff}
          currentMonthTotalWorkCount={currentMonthSummary.totalWork}
          currentMonthRemainingWorkCount={currentMonthSummary.remainingWork}
          lastSyncedAt={selectedHolidaySource?.lastSyncedAt ?? null}
          availableSoundCount={Math.max(0, availableSounds.length - 1)}
          alarmCardGradientEnabled={alarmCardGradientEnabled}
          onOpenSoundSettings={() => {
            void openSoundSettings()
          }}
          onAlarmCardGradientEnabledChange={updateAlarmCardGradientEnabled}
        />
      </NavigationStack>
    )
  }

  function renderAlarmsTab() {
    return (
      <NavigationStack>
        <List
          navigationTitle="闹钟"
          navigationBarTitleDisplayMode="inline"
          listStyle="insetGroup"
          toolbar={{
            topBarTrailing: (
              <Button
                title=""
                systemImage="gearshape"
                action={() => {
                  void openSystemAlarmSettings()
                }}
              />
            ),
          }}
        >
          {!AlarmManager.isAvailable ? (
            <Text foregroundStyle="secondaryLabel">当前系统不支持 AlarmManager。</Text>
          ) : records.length ? (
            <ForEach
              count={records.length}
              onMove={moveRecords}
              itemBuilder={(index) => {
                const record = records[index]
                if (!record) return <Text> </Text>
                return (
                  <VStack
                    key={`${record.id}-${record.updatedAt}`}
                    frame={{ maxWidth: "infinity", alignment: "leading" as any }}
                    background="rgba(0,0,0,0.001)"
                    contentShape={{ kind: "interaction", shape: { type: "rect" } } as any}
                    listRowInsets={{ top: 6, bottom: 6, leading: 12, trailing: 12 }}
                    listRowSeparator="hidden"
                    listRowBackground={<EmptyView />}
                    trailingSwipeActions={rowSwipeActions({
                      onEdit: () => {
                        void editAlarm(record)
                      },
                      onDelete: () => {
                        void removeAlarm(record)
                      },
                    })}
                  >
                    <AlarmRow
                      record={record}
                      subtitle={displaySubtitle(record, holidaySourceMap)}
                      nextDateText={nextOccurrenceDateLabel(record, holidaySourceMap)}
                      gradientEnabled={alarmCardGradientEnabled}
                      onToggle={toggleAlarm}
                    />
                  </VStack>
                )
              }}
            />
          ) : (
            <Text foregroundStyle="secondaryLabel">点击底部右侧按钮创建一个闹钟。</Text>
          )}
        </List>
      </NavigationStack>
    )
  }

  function renderCalendarsTab() {
    return (
      <NavigationStack>
        <CalendarSettingsView
          embedded
          sources={holidaySources}
          isRefreshing={calendarRefreshing}
        />
      </NavigationStack>
    )
  }

  async function removeAlarm(record: AlarmRecord) {
    if (globalBusy || busyRecordId) return
    setGlobalBusy(true)
    setAlarmDeleting(true)
    const systemAlarmMap = new Map(systemAlarms.map((item) => [item.id, item]))
    const nextCleanupCandidateIds = mergeManagedSystemAlarmIds(cleanupCandidateAlarmIds, record.systemAlarmIds)
    const nextRecords = records.filter((item) => item.id !== record.id)
    try {
      setRecords(nextRecords)
      setCleanupCandidateAlarmIds(nextCleanupCandidateIds)
      saveStateSnapshot(nextRecords, holidaySources, availableSounds, managedSystemAlarmIds, nextCleanupCandidateIds)

      // 先取消系统里已经注册的实例，再从首页记录里删掉它。
      await deleteAlarm(record, systemAlarmMap)
      await refreshSystemState()
    } catch (error: any) {
      setRecords(records)
      setCleanupCandidateAlarmIds(cleanupCandidateAlarmIds)
      saveStateSnapshot(records, holidaySources, availableSounds, managedSystemAlarmIds, cleanupCandidateAlarmIds)
      await Dialog.alert({ message: String(error?.message ?? error) })
    } finally {
      setAlarmDeleting(false)
      setGlobalBusy(false)
    }
  }

  async function deleteSystemAlarmIds(ids: string[]) {
    if (globalBusy || busyRecordId) return
    if (!ids.length) {
      return {
        items: buildAdvancedCleanupItems(systemAlarms, records, cleanupCandidateAlarmIds),
        diagnosticItems: buildDiagnosticItems(systemAlarms, records, managedSystemAlarmIds, cleanupCandidateAlarmIds),
      }
    }

    setGlobalBusy(true)
    try {
      await cancelManagedSystemAlarmIds(ids)

      const removedIdSet = new Set(ids)
      const nextRecords = records.map((record) => {
        const nextIds = record.systemAlarmIds.filter((id) => !removedIdSet.has(id))
        if (nextIds.length === record.systemAlarmIds.length) return record
        return {
          ...record,
          enabled: nextIds.length ? record.enabled : false,
          systemAlarmIds: nextIds,
          lastScheduledAt: nextIds.length ? record.lastScheduledAt : null,
          updatedAt: Date.now(),
        }
      })
      const nextManagedIds = managedSystemAlarmIds.filter((id) => !removedIdSet.has(id))
      const nextCleanupCandidateIds = cleanupCandidateAlarmIds.filter((id) => !removedIdSet.has(id))

      setRecords(nextRecords)
      setManagedSystemAlarmIds(nextManagedIds)
      setCleanupCandidateAlarmIds(nextCleanupCandidateIds)
      saveStateSnapshot(nextRecords, holidaySources, availableSounds, nextManagedIds, nextCleanupCandidateIds)
      const snapshot = await refreshSystemState()
      return snapshot
    } catch (error: any) {
      await Dialog.alert({ message: String(error?.message ?? error) })
      return {
        items: buildAdvancedCleanupItems(systemAlarms, records, cleanupCandidateAlarmIds),
        diagnosticItems: buildDiagnosticItems(systemAlarms, records, managedSystemAlarmIds, cleanupCandidateAlarmIds),
      }
    } finally {
      setGlobalBusy(false)
    }
  }

  async function refreshStatusPanel() {
    if (busyRecordId) return
    await refreshAvailableSounds({ showError: false })
    await refreshSystemState()
  }

  async function refreshAvailableSounds(options?: { showError?: boolean }): Promise<string[]> {
    try {
      const nextSounds = await loadAvailableSoundNames()
      setAvailableSounds(nextSounds)
      saveStateSnapshot(records, holidaySources, nextSounds, managedSystemAlarmIds, cleanupCandidateAlarmIds)
      return nextSounds
    } catch (error: any) {
      if (options?.showError === false) return availableSounds
      await Dialog.alert({ message: String(error?.message ?? error) })
      return availableSounds
    }
  }

  function replaceSoundName(oldSound: string, newSound: string) {
    const nextSounds = availableSounds.map((sound) => (sound === oldSound ? newSound : sound))
    setAvailableSounds(nextSounds)
    setRecords((current) => {
      const nextRecords = current.map((record) => (
        record.soundName === oldSound
          ? { ...record, soundName: newSound, updatedAt: Date.now() }
          : record
      ))
      saveStateSnapshot(nextRecords, holidaySources, nextSounds, managedSystemAlarmIds, cleanupCandidateAlarmIds)
      return nextRecords
    })
  }

  function removeSoundName(sound: string) {
    const nextSounds = availableSounds.filter((item) => item !== sound)
    setAvailableSounds(nextSounds)
    setRecords((current) => {
      const nextRecords = current.map((record) => (
        record.soundName === sound
          ? { ...record, soundName: DEFAULT_SOUND_NAME, updatedAt: Date.now() }
          : record
      ))
      saveStateSnapshot(nextRecords, holidaySources, nextSounds, managedSystemAlarmIds, cleanupCandidateAlarmIds)
      return nextRecords
    })
  }

  async function openSoundSettings() {
    const nextSounds = await refreshAvailableSounds({ showError: false })
    await Navigation.present({
      element: (
        <SoundSettingsView
          sounds={nextSounds}
          onRefresh={refreshAvailableSounds}
          onSoundDeleted={removeSoundName}
          onSoundRenamed={replaceSoundName}
        />
      ),
    })
    await refreshAvailableSounds({ showError: false })
  }

  async function refreshBuiltinHolidayCalendar(options?: { showLoading?: boolean }) {
    if (busyRecordId) return
    const source = holidaySources.find((item) => item.id === DEFAULT_HOLIDAY_SOURCE_ID) ?? holidaySources[0] ?? null
    if (!source) return

    if (options?.showLoading !== false) setCalendarRefreshing(true)
    try {
      const synced = await syncHolidayCalendarSource(source)
      const updatedSources = holidaySources.map((item) => (item.id === synced.id ? synced : item))
      await applyHolidaySources(updatedSources, { muteBusy: true })
    } catch (error: any) {
      await Dialog.alert({ message: String(error?.message ?? error) })
    } finally {
      if (options?.showLoading !== false) setCalendarRefreshing(false)
    }
  }

  function accessoryIconName() {
    return lastContentTab === ALARMS_TAB ? "plus" : "arrow.clockwise"
  }

  return (
    <ZStack sheet={releaseNotesSheet}>
      <TabView
        selection={activeTab as any}
        tint="systemOrange"
        tabViewStyle="sidebarAdaptable"
        tabBarMinimizeBehavior="onScrollDown"
        tabViewSearchActivation="searchTabSelection"
      >
        <Tab
          title="状态"
          systemImage="chart.bar.fill"
          value={STATUS_TAB}
        >
          {renderStatusTab()}
        </Tab>

        <Tab
          title="闹钟"
          systemImage="alarm.fill"
          value={ALARMS_TAB}
        >
          {renderAlarmsTab()}
        </Tab>

        <Tab
          title="日历"
          systemImage="calendar"
          value={CALENDARS_TAB}
        >
          {renderCalendarsTab()}
        </Tab>

        <Tab
          title=""
          systemImage={accessoryIconName()}
          value={ACTION_TAB}
          role="search"
        >
          {lastContentTab === STATUS_TAB
            ? renderStatusTab()
            : lastContentTab === ALARMS_TAB
              ? renderAlarmsTab()
              : renderCalendarsTab()}
        </Tab>
      </TabView>

      {alarmWriting || alarmDeleting ? (
        <VStack
          spacing={12}
          frame={{ maxWidth: "infinity", maxHeight: "infinity", alignment: "center" as any }}
          contentShape="rect"
        >
          <VStack
            spacing={12}
            padding={{ top: 20, bottom: 20, leading: 24, trailing: 24 }}
            shadow={{
              color: colorScheme === "dark" ? "rgba(0,0,0,0.35)" : "rgba(0,0,0,0.12)",
              radius: 20,
              y: 8,
            }}
            background={{
              style: colorScheme === "dark" ? "#1F1F22" : "#FFFFFF",
              shape: { type: "rect", cornerRadius: 20 },
            }}
          >
            <ProgressView progressViewStyle="circular" />
            <Text font="subheadline" foregroundStyle="secondaryLabel">
              {alarmWriting ? "正在写入闹钟..." : "正在删除闹钟..."}
            </Text>
          </VStack>
        </VStack>
      ) : null}
    </ZStack>
  )
}
