Rook 0.1.0 便携版（Windows 10/11 x64）
=====================================

启动
----
1. 把整个目录解压到任意本地目录（建议路径不含中文与空格）；
2. 双击 Rook.exe 启动。Rook.exe 必须与同目录的 WebView2Loader.dll 放在一起；
3. 系统需要 Microsoft Edge WebView2 Runtime（Windows 11 与较新的 Windows 10 已预装）。

行为
----
- 双击启动显示主窗口；点窗口关闭按钮只是销毁界面，应用继续驻留托盘；
- 左键托盘图标或再次双击 Rook.exe 可重新打开（单实例，不会开第二个进程）；
- 托盘菜单「退出」才会结束应用，并按预算优雅停止受监督的脚本。

配置与数据
----------
- 便携配置（可选）：把 Rook.toml 放在 Rook.exe 同目录，即优先于安装版配置；
- 默认配置：%APPDATA%\Rook\config.toml（首次启动自动创建带注释的模板）；
- 默认数据：%LOCALAPPDATA%\Rook，可在 [app].data_dir 或 --data-dir 中修改；
- 日志：<数据目录>\logs\<task_id>\current.log；核心日志：<数据目录>\core\rook.log。

注意
----
- 本构建未做代码签名，Windows SmartScreen 可能提示；请先核对 SHA256SUMS.txt；
- 卸载/清理：先在托盘退出 Rook，再删除本目录；如需彻底清理，同时删除
  %APPDATA%\Rook 与 %LOCALAPPDATA%\Rook；
- 应用不会上传任何数据；任务日志可能含业务信息，分享诊断包前请检查。

项目主页：https://github.com/yuanarcsin/Rook

许可
----
本项目采用 PolyForm Noncommercial License 1.0.0：源码可见、可修改、可分发，
但仅限非商业用途；商业使用需单独授权。完整条款见同目录 LICENSE.txt 与
https://polyformproject.org/licenses/noncommercial/1.0.0

