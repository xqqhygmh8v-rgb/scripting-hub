Imprint UI v0.1 — showcase (Windows x64)
==========================================

A software-rendered GUI framework demo: device-status control panel plus an
all-widgets gallery, declared in .ui design files. No GPU, no OS GUI toolkit.

Run: double-click showcase.exe (or run it from a terminal).

Contents
  showcase.exe        the demo app (window opens at 320x240)
  imcore.dll          rendering core
  MSVCP140.dll, VCRUNTIME140.dll, VCRUNTIME140_1.dll
                      bundled Visual C++ runtime (Microsoft VC++ Redistributable
                      components, redistributed under their license)

More targets
  Try it live in your browser (WebAssembly): https://tyouhyou.github.io/imprint/
  Nintendo DS ROM: see the release assets (runs in melonDS or on flashcarts)
  Build from source: https://github.com/tyouhyou/imprint (README -> Build)

MIT license. Source and docs: https://github.com/tyouhyou/imprint
