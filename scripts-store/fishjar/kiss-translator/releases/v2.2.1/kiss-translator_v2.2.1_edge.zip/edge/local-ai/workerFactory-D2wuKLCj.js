const r=()=>new Worker(new URL("/local-ai/scriptWorker-BQUtzirN.js",import.meta.url));export{r as createProviderWorker};
