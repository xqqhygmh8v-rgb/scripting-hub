const s="/local-ai/ort-wasm-simd-threaded.asyncify-DMmc6YqF.wasm",a="/local-ai/ort-wasm-simd-threaded.asyncify-CVnZHRES.mjs",m={wasm:s,mjs:a};export{m as O};
