const r=()=>new Worker(new URL("/local-ai/scriptWorker-hoRUJmQW.js",import.meta.url));export{r as createProviderWorker};
